// Dark mode removed: ensure no `data-theme` attribute remains
document.documentElement.removeAttribute('data-theme');

const firstStartTrustedTypesPolicy = window.trustedTypes
  ? window.trustedTypes.createPolicy('first-start', { createHTML: (value) => value })
  : { createHTML: (value) => value };

function escapeHTML(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  }[char]));
}

// Persist signup intent early so header logic can read it on load
(function setSignupIntentFromPath() {
  try {
    const p = (window.location && window.location.pathname) || '/';
    if (p.startsWith('/signup/manager')) {
      sessionStorage.setItem('signup_intent', 'manager');
    } else if (p.startsWith('/signup/seeker')) {
      sessionStorage.setItem('signup_intent', 'seeker');
    } else if (p === '/signup') {
      // selection page — clear any previous intent so navbar stays minimal
      sessionStorage.removeItem('signup_intent');
    }
  } catch (e) { /* ignore storage errors */ }
})();

// Copy code functionality
function copyCode(button) {
  const codeBlock = button.closest('.code-block');
  const code = codeBlock.querySelector('code').textContent;
  
  navigator.clipboard.writeText(code).then(() => {
    const originalText = button.textContent;
    button.textContent = 'Copied!';
    setTimeout(() => {
      button.textContent = originalText;
    }, 2000);
  }).catch(err => {
    console.error('Failed to copy code:', err);
  });
}

function getCurrentUser() {
  return window.__USER__ || window.__CURRENT_USER__ || null;
}

function redirectToAuthGate(nextPath, label) {
  const safeNext = nextPath || window.location.pathname || '/';
  const safeLabel = label ? `&label=${encodeURIComponent(label)}` : '';
  window.location.href = `/auth-gate?next=${encodeURIComponent(safeNext)}${safeLabel}`;
}

function requireAuthForAction(nextPath, label, event) {
  if (getCurrentUser()) return true;
  if (event) {
    event.preventDefault();
    event.stopPropagation();
  }
  redirectToAuthGate(nextPath, label);
  return false;
}

function initPageAnimations() {
  try {
    if (!document.body) return;
    const reducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reducedMotion) {
      document.body.classList.remove('page-motion-ready');
      return;
    }

    document.body.classList.add('page-motion-ready');

    const selectors = [
      'main > .container',
      'main > section',
      'main > article',
      'main > .row',
      '.dashboard-panel',
      '.page-header',
      '.card',
      '.hero',
      '.feature-card',
      '.path-card',
      '.step-card',
      '.team-card',
      '.recruit-card',
      '.resource-card',
      '.info-card',
      '.panel',
      '.stats-grid > *',
      '.team-history-item',
      '.team-compare-card',
      '.teams-list > *',
      '.account-section',
      '.form-grid',
      '.auth-card'
    ];

    const targets = Array.from(document.querySelectorAll(selectors.join(',')));
    if (!targets.length) return;

    const seen = new WeakSet();
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -4% 0px' });

    targets.forEach((target, index) => {
      if (seen.has(target)) return;
      seen.add(target);
      target.classList.add('reveal-on-scroll');
      target.style.transitionDelay = `${Math.min(index, 14) * 35}ms`;
      observer.observe(target);
    });
  } catch (err) {
    // Animation is decorative only; never block page behavior if it fails.
  }
}

// ---------- Join form + Teams pages logic ----------

const STUDENT_KEY = 'studentInfo_v1';

// Remove applicant PII copied into browser storage by older releases.
try {
  sessionStorage.removeItem(STUDENT_KEY);
  localStorage.removeItem(STUDENT_KEY);
} catch (e) {}

function initJoinForm() {
  const form = document.getElementById('joinForm');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/signups', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ currentGrade: form.elements.currentGrade.value.trim() })
      });
      const payload = await response.json().catch(() => ({}));
      if (response.status === 401) {
        redirectToAuthGate('/join-form', 'Join a Team');
        return;
      }
      if (!response.ok) {
        alert(payload.error || 'Unable to save your profile right now.');
        return;
      }
      window.location.href = '/teams-nearby';
    } catch (err) {
      console.error('Failed to save to database:', err);
      alert('Unable to save your profile right now.');
    }
  });
}

function initAuthGatedActions() {
  const startTeamCards = document.querySelectorAll('.roadmap-card');
  startTeamCards.forEach((card) => {
    if (card.dataset.authBound) return;
    card.dataset.authBound = 'true';
    card.addEventListener('click', (event) => {
      const target = card.getAttribute('href') || '/start-team';
      const label = (card.querySelector('strong') || card.querySelector('h3') || card).textContent.trim();
      requireAuthForAction(target, label, event);
    });
  });

  const resourceLinks = document.querySelectorAll('.resource-links a');
  const publicResourcePaths = new Set([
    '/sdk',
    '/programming',
    '/advanced-programming',
    '/controller-setup',
    '/drivetrain',
    '/mechanical-parts',
    '/assembly',
    '/motor-selection',
    '/funding',
    '/sponsorship',
    '/outreach',
    '/team-org'
  ]);
  resourceLinks.forEach((link) => {
    if (link.dataset.authBound) return;
    if (link.dataset.publicResource === 'true' || link.origin !== window.location.origin) return;
    if (link.pathname.startsWith('/resources/') || publicResourcePaths.has(link.pathname)) return;
    link.dataset.authBound = 'true';
    link.addEventListener('click', (event) => {
      requireAuthForAction(link.getAttribute('href') || '/resources', (link.textContent || '').trim(), event);
    });
  });
}

function isTeamRecruiting(team) {
  const value = team && typeof team === 'object' ? team.recruiting : undefined;
  if (value === false || value === 0) return false;

  const normalized = String(value ?? '').trim().toLowerCase();
  if (!normalized) return true;
  if (['false', '0', 'off', 'no', 'n', 'inactive', 'not recruiting'].includes(normalized)) {
    return false;
  }

  return true;
}

function normalizeCountryName(value) {
  const normalized = String(value || '')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim()
    .replace(/\s+/g, ' ');
  const aliases = {
    us: 'united states',
    'u s': 'united states',
    usa: 'united states',
    'u s a': 'united states',
    'united states of america': 'united states',
    uk: 'united kingdom',
    'u k': 'united kingdom',
    gb: 'united kingdom',
    'great britain': 'united kingdom',
    uae: 'united arab emirates',
    'u a e': 'united arab emirates'
  };
  return aliases[normalized] || normalized;
}

function normalizeRegionName(value) {
  return String(value || '')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim()
    .replace(/\s+/g, ' ');
}

function getCountryApplicationState(team) {
  const user = getCurrentUser();
  if (!user) return { hasTeam: false, needsCountry: false, needsRegion: false, outsideCountry: false, outsideRegion: false };
  const userCountry = normalizeCountryName(user.country);
  const teamCountry = normalizeCountryName(team && team.country);
  const userRegion = normalizeRegionName(user.canonicalState || user.state);
  const teamRegion = normalizeRegionName(team && (team.canonicalState || team.state));
  return {
    hasTeam: Boolean(user.hasTeam),
    needsCountry: !userCountry,
    needsRegion: Boolean(userCountry && !userRegion),
    outsideCountry: Boolean(userCountry && (!teamCountry || userCountry !== teamCountry)),
    outsideRegion: Boolean(userCountry && teamCountry && userCountry === teamCountry && userRegion && (!teamRegion || userRegion !== teamRegion))
  };
}

function initDeclarativeActions() {
  document.querySelectorAll('[data-copy-code]').forEach((button) => {
    button.addEventListener('click', () => copyCode(button));
  });
  document.querySelectorAll('[data-auto-submit]').forEach((field) => {
    field.addEventListener('change', () => {
      if (field.form) field.form.requestSubmit();
    });
  });
}

// A small list of sample teams retained for legacy integrations.
const SAMPLE_TEAMS = [
  { name: 'Rookie Robotics', lat: 40.7128, lon: -74.0060, contact: 'rookierobotics@example.com' },
  { name: 'Northside FTC', lat: 40.730610, lon: -73.935242, contact: 'northsideftc@example.com' },
  { name: 'Riverdale Robotics', lat: 40.6782, lon: -73.9442, contact: 'riverdalerobotics@example.com' }
];

const LEGACY_EMPTY_TEAM_REQUIREMENTS = new Set([
  'Add your team requirements, such as meeting schedule, grades accepted, skills needed, or application steps.'
].map(value => value.toLowerCase()));

function getTeamRequirementsText(value) {
  const requirements = String(value || '').trim();
  if (!requirements || LEGACY_EMPTY_TEAM_REQUIREMENTS.has(requirements.toLowerCase())) {
    return 'None';
  }
  return requirements;
}

function haversineDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // km
  const toRad = (v) => v * Math.PI / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

function getDistanceUnitPreference() {
  const locale = String(
    navigator.language ||
    Intl.DateTimeFormat().resolvedOptions().locale ||
    ''
  );
  const regionMatch = locale.match(/[-_](?<region>[A-Z]{2}|\d{3})$/);
  const region = regionMatch && regionMatch.groups ? regionMatch.groups.region : '';
  return new Set(['US', 'LR', 'MM', 'GB']).has(region) ? 'imperial' : 'metric';
}

function formatDistance(distanceKm, unitPreference) {
  const useImperial = unitPreference === 'imperial';
  const value = useImperial ? distanceKm * 0.621371 : distanceKm;
  const unit = useImperial ? 'mi' : 'km';
  return {
    value,
    label: `${value.toFixed(2)} ${unit}`
  };
}

function formatAwardHistoryDisplayEntry(entry) {
  const value = String(entry || '').trim();
  if (!value) return '';
  return value.replace(/^\s*(Winner|Finalist)\b/i, (_, word) => (
    word.toLowerCase() === 'winner' ? 'Winning Alliance' : 'Finalist Alliance'
  ));
}

function distanceThresholdToKm(value, unitPreference) {
  if (!Number.isFinite(value)) return null;
  return unitPreference === 'imperial' ? value / 0.621371 : value;
}

const TEAM_PRIVACY_RADIUS_METERS = 152.4; // 500 feet
const TEAM_MARKER_OFFSET_METERS = 60.96; // 200 feet

function getPrivacyOffsetPosition(team, latitude, longitude) {
  const seed = String((team && (team.id || team._id || team.name || team.teamNumber)) || 'team');
  let hash = 0;
  for (let index = 0; index < seed.length; index += 1) {
    hash = ((hash * 31) + seed.charCodeAt(index)) >>> 0;
  }
  const angle = (hash % 360) * (Math.PI / 180);
  const latitudeOffset = (TEAM_MARKER_OFFSET_METERS * Math.cos(angle)) / 111320;
  const longitudeScale = 111320 * Math.max(0.2, Math.cos(latitude * (Math.PI / 180)));
  const longitudeOffset = (TEAM_MARKER_OFFSET_METERS * Math.sin(angle)) / longitudeScale;
  return {
    lat: latitude + latitudeOffset,
    lng: longitude + longitudeOffset
  };
}

window.initGoogleTeamsMap = function initGoogleTeamsMap() {
  window.__GOOGLE_MAPS_READY__ = true;
  window.dispatchEvent(new Event('google-maps-ready'));
};

function getGoogleHtmlMarkerClass() {
  if (window._GoogleHtmlMarkerClass) return window._GoogleHtmlMarkerClass;

  class GoogleHtmlMarker extends google.maps.OverlayView {
    constructor({ map, position, title, html, className = '', interactive = true, onClick, onMouseOver, onMouseOut }) {
      super();
      this.position = new google.maps.LatLng(position);
      this.title = title || '';
      this.html = html || '';
      this.className = className;
      this.interactive = interactive;
      this.onClickHandler = onClick;
      this.onMouseOverHandler = onMouseOver;
      this.onMouseOutHandler = onMouseOut;
      this.visible = true;
      this.compact = false;
      this.element = null;
      this.setMap(map);
    }

    onAdd() {
      const element = document.createElement('div');
      element.className = `google-team-overlay ${this.className}`.trim();
      // Avoid a native tooltip competing with the delayed team popup.
      element.removeAttribute('title');
      element.innerHTML = firstStartTrustedTypesPolicy.createHTML(this.html);
      if (this.interactive) {
        element.setAttribute('role', 'button');
        element.tabIndex = 0;
        element.setAttribute('aria-label', this.title);
        element.addEventListener('click', event => {
          event.preventDefault();
          event.stopPropagation();
          if (this.onClickHandler) this.onClickHandler(event);
        });
        element.addEventListener('keydown', event => {
          if (event.key !== 'Enter' && event.key !== ' ') return;
          event.preventDefault();
          if (this.onClickHandler) this.onClickHandler(event);
        });
      }
      if (this.onMouseOverHandler) element.addEventListener('mouseenter', this.onMouseOverHandler);
      if (this.onMouseOutHandler) element.addEventListener('mouseleave', this.onMouseOutHandler);
      element.hidden = !this.visible;
      element.classList.toggle('is-compact', this.compact);
      this.element = element;
      this.getPanes().overlayMouseTarget.appendChild(element);
    }

    draw() {
      if (!this.element) return;
      const point = this.getProjection().fromLatLngToDivPixel(this.position);
      if (!point) return;
      this.element.style.left = `${point.x}px`;
      this.element.style.top = `${point.y}px`;
    }

    onRemove() {
      if (this.element) this.element.remove();
      this.element = null;
    }

    getPosition() {
      return this.position;
    }

    setVisible(visible) {
      this.visible = Boolean(visible);
      if (this.element) this.element.hidden = !this.visible;
    }

    setCompact(compact) {
      this.compact = Boolean(compact);
      if (this.element) this.element.classList.toggle('is-compact', this.compact);
    }
  }

  window._GoogleHtmlMarkerClass = GoogleHtmlMarker;
  return GoogleHtmlMarker;
}

function getGooglePrivacyOverlayClass() {
  if (window._GooglePrivacyOverlayClass) return window._GooglePrivacyOverlayClass;

  class GooglePrivacyOverlay extends google.maps.OverlayView {
    constructor({ map, position, radiusMeters }) {
      super();
      this.position = new google.maps.LatLng(position);
      this.radiusMeters = Number(radiusMeters) || 220;
      this.visible = false;
      this.element = null;
      this.setMap(map);
    }

    onAdd() {
      const element = document.createElement('div');
      element.className = 'google-team-privacy-overlay';
      element.setAttribute('aria-hidden', 'true');
      element.hidden = !this.visible;
      this.element = element;
      // Keep the privacy visualization in the non-interactive pane so it can
      // never block clicks intended for the red team marker.
      this.getPanes().overlayLayer.appendChild(element);
    }

    draw() {
      if (!this.element) return;
      const projection = this.getProjection();
      const center = projection.fromLatLngToDivPixel(this.position);
      const north = projection.fromLatLngToDivPixel(new google.maps.LatLng(
        this.position.lat() + (this.radiusMeters / 111320),
        this.position.lng()
      ));
      if (!center || !north) return;
      // Size the overlay from its fixed real-world radius rather than a
      // screen-space minimum or maximum.
      const diameter = Math.abs(center.y - north.y) * 2;
      this.element.style.width = `${diameter}px`;
      this.element.style.height = `${diameter}px`;
      this.element.style.left = `${center.x - (diameter / 2)}px`;
      this.element.style.top = `${center.y - (diameter / 2)}px`;
    }

    onRemove() {
      if (this.element) this.element.remove();
      this.element = null;
    }

    setVisible(visible) {
      this.visible = Boolean(visible);
      if (this.element) this.element.hidden = !this.visible;
    }
  }

  window._GooglePrivacyOverlayClass = GooglePrivacyOverlay;
  return GooglePrivacyOverlay;
}

function createUserLocationMarker(map, userCoords, bounds) {
  if (!map || !userCoords || typeof userCoords.lat !== 'number' || typeof userCoords.lon !== 'number') return null;

  const GoogleHtmlMarker = getGoogleHtmlMarkerClass();
  const position = { lat: userCoords.lat, lng: userCoords.lon };
  const marker = new GoogleHtmlMarker({
    map,
    position,
    interactive: false,
    className: 'google-user-overlay',
    title: 'Your location',
    html: `
      <div class="user-location-marker-wrap" aria-hidden="true">
        <span class="user-location-marker-tag">Your location</span>
        <span class="team-zoom-notifier team-zoom-notifier--user"></span>
      </div>
    `
  });

  if (bounds) {
    bounds.extend(position);
  }

  return marker;
}

function renderTeams(teams, userCoords) {
  const list = document.getElementById('teamsList');
  if (!list) return;
  const mapRenderVersion = (window._teamsMapRenderVersion || 0) + 1;
  window._teamsMapRenderVersion = mapRenderVersion;

  const hasUserCoords = userCoords
    && Number.isFinite(Number(userCoords.lat))
    && Number.isFinite(Number(userCoords.lon));
  const orderedTeams = hasUserCoords
    ? teams.slice().sort((left, right) => {
      const leftDistance = haversineDistance(userCoords.lat, userCoords.lon, Number(left.lat), Number(left.lon));
      const rightDistance = haversineDistance(userCoords.lat, userCoords.lon, Number(right.lat), Number(right.lon));
      if (!Number.isFinite(leftDistance)) return 1;
      if (!Number.isFinite(rightDistance)) return -1;
      return leftDistance - rightDistance || String(left.name || '').localeCompare(String(right.name || ''));
    })
    : teams;

  // clear list
  list.replaceChildren();
  window._teamMarkers = {};
  window._userLocationMarker = null;
  window._infoWindowTimer = null;
  window._infoWindow = null; // Reset infoWindow to ensure it's recreated with new map instance
  window._teamCards = {};

  // ensure a map container exists above the list
  let mapEl = document.getElementById('teamsMap');
  if (!mapEl) {
    mapEl = document.createElement('div');
    mapEl.id = 'teamsMap';
    mapEl.style.width = '100%';
    mapEl.style.height = '400px';
    list.parentNode.insertBefore(mapEl, list);
  }

  // create a simple accessible list alongside the map
  const programOptions = ['All', 'FLL Challenge', 'FTC', 'FRC'];
  const distanceUnitPreference = getDistanceUnitPreference();
  const distanceFilterOptions = distanceUnitPreference === 'imperial'
    ? [
        { value: 'all', label: 'Any distance' },
        { value: '5', label: 'Within 5 mi' },
        { value: '10', label: 'Within 10 mi' },
        { value: '25', label: 'Within 25 mi' },
        { value: '50', label: 'Within 50 mi' }
      ]
    : [
        { value: 'all', label: 'Any distance' },
        { value: '5', label: 'Within 5 km' },
        { value: '10', label: 'Within 10 km' },
        { value: '25', label: 'Within 25 km' },
        { value: '50', label: 'Within 50 km' }
      ];
  const searchWrap = document.createElement('div');
  searchWrap.className = 'teams-search';
  searchWrap.innerHTML = firstStartTrustedTypesPolicy.createHTML(`
    <label for="teamsSearch">Search teams</label>
    <div class="teams-search-row">
      <div class="teams-search-field">
        <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
        <input id="teamsSearch" type="search" placeholder="Search by team or location" autocomplete="off" />
        <div class="teams-filter-menu">
          <button type="button" class="teams-filter-button" aria-haspopup="true" aria-expanded="false" aria-controls="teamsProgramDropdown">
            <i class="fa-solid fa-filter" aria-hidden="true"></i>
            <span>Filters</span>
          </button>
          <div id="teamsProgramDropdown" class="teams-filter-dropdown" hidden>
            <label for="teamsProgramFilter">FIRST program</label>
            <select id="teamsProgramFilter" class="teams-program-filter" aria-label="Filter teams by FIRST program">
              ${programOptions.map(program => `<option value="${escapeHTML(program)}">${program === 'All' ? 'All programs' : escapeHTML(program)}</option>`).join('')}
            </select>
            <label for="teamsAwardsFilter">Awards</label>
            <select id="teamsAwardsFilter" class="teams-program-filter" aria-label="Filter teams by awards">
              <option value="all">All teams</option>
              <option value="has-awards">Has awards listed</option>
              <option value="no-awards">No awards listed</option>
            </select>
            <label for="teamsYearsFilter">Years in program</label>
            <select id="teamsYearsFilter" class="teams-program-filter" aria-label="Filter teams by years in program">
              <option value="all">All years</option>
              <option value="new-team">New teams</option>
              <option value="rookie">Rookie (1-2 years)</option>
              <option value="mid">3-5 years</option>
              <option value="veteran">6+ years</option>
              <option value="unknown">Unknown</option>
            </select>
            <label for="teamsAdvancementFilter">Advancement</label>
            <select id="teamsAdvancementFilter" class="teams-program-filter" aria-label="Filter teams by advancement level">
              <option value="all">All advancement</option>
              <option value="Qualifier">Qualifiers</option>
              <option value="Regional">Regionals</option>
              <option value="Worlds">Worlds</option>
              <option value="unknown">Unknown</option>
            </select>
            <label for="teamsDistanceFilter">Distance</label>
            <select id="teamsDistanceFilter" class="teams-program-filter" aria-label="Filter teams by distance">
              ${distanceFilterOptions.map(option => `<option value="${option.value}">${escapeHTML(option.label)}</option>`).join('')}
            </select>
            <div class="teams-filter-actions">
              <button type="button" class="teams-filter-clear">Clear filters</button>
            </div>
          </div>
        </div>
      </div>
      <span class="teams-search-count" aria-live="polite"></span>
    </div>
  `);

  const teamsListContainer = document.createElement('div');
  teamsListContainer.className = 'teams-list-container';

  teamsListContainer.appendChild(searchWrap);

  const emptyEl = document.createElement('p');
  emptyEl.className = 'teams-empty';
  emptyEl.hidden = true;
  emptyEl.textContent = 'No teams match your search.';
  teamsListContainer.appendChild(emptyEl);

  const listEl = document.createElement('div');
  listEl.className = 'teams-list-cards';
  const listViewport = document.createElement('div');
  listViewport.className = 'teams-list-viewport';
  listViewport.appendChild(listEl);
  teamsListContainer.appendChild(listViewport);

  const paginationEl = document.createElement('nav');
  paginationEl.className = 'teams-pagination';
  paginationEl.setAttribute('aria-label', 'Team result pages');
  teamsListContainer.appendChild(paginationEl);

  list.appendChild(teamsListContainer);

  const searchInput = searchWrap.querySelector('#teamsSearch');
  const programFilter = searchWrap.querySelector('#teamsProgramFilter');
  const awardsFilter = searchWrap.querySelector('#teamsAwardsFilter');
  const yearsFilter = searchWrap.querySelector('#teamsYearsFilter');
  const advancementFilter = searchWrap.querySelector('#teamsAdvancementFilter');
  const distanceFilter = searchWrap.querySelector('#teamsDistanceFilter');
  const filterMenu = searchWrap.querySelector('.teams-filter-menu');
  const filterButton = searchWrap.querySelector('.teams-filter-button');
  const filterDropdown = searchWrap.querySelector('.teams-filter-dropdown');
  const clearFiltersButton = searchWrap.querySelector('.teams-filter-clear');
  const resultCount = searchWrap.querySelector('.teams-search-count');
  const teamsPerPage = 5;
  let currentPage = 1;

  function escapeHTML(value) {
    return String(value ?? '').replace(/[&<>"']/g, char => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;'
    }[char]));
  }

function normalizeAdvancementLevel(level) {
  const value = String(level ?? '').trim().toLowerCase();
  if (!value) return '';
  if (value.includes('scrimmag')) return '';
    if (value.startsWith('qual') || value.includes('super qualifier') || value.includes('league tournament') || value.includes('league meet')) return 'Qualifier';
    if (value.startsWith('reg') || value.includes('premier')) return 'Regional';
    if (value.startsWith('world') || value.includes('first championship') || value.includes('firstchampionship') || value.includes('world championship')) return 'Worlds';
    if (value.includes('championship')) return 'Regional';
  return level;
}

function getTeamRecruitingLabel(team) {
  return isTeamRecruiting(team) ? 'Recruiting' : 'Not recruiting';
}

  function advancementLevelRank(level) {
    const normalized = normalizeAdvancementLevel(level);
    if (normalized === 'Worlds') return 3;
    if (normalized === 'Regional') return 2;
    if (normalized === 'Qualifier') return 1;
    return 0;
  }

  function sortAdvancementLevels(levels) {
    return Array.isArray(levels)
      ? Array.from(new Set(levels.map(normalizeAdvancementLevel).filter(Boolean)))
        .sort((left, right) => {
          const diff = advancementLevelRank(right) - advancementLevelRank(left);
          if (diff) return diff;
          return String(left).localeCompare(String(right));
        })
      : [];
  }

  function formatAdvancementEntry(entry, levels, index) {
    const value = String(entry ?? '').trim();
    if (!value) return '';
    if (/^(Qualifier|Regional|Worlds|Super Qualifier|League Tournament|League Meet|Premier|Championship)\b/i.test(value) && /\d{4}/.test(value)) {
      return value.replace(/\s*-\s*/g, ' - ');
    }
    if (/^(Qualifier|Regional|Worlds|Super Qualifier|League Tournament|League Meet|Premier|Championship)\b/i.test(value)) return value;
    if (/^(?:19|20)\d{2}$/.test(value)) {
      const orderedLevels = sortAdvancementLevels(levels);
      const level = orderedLevels.length ? orderedLevels[index % orderedLevels.length] : '';
      return level ? `${level} - ${value}` : value;
    }
    return value;
  }

  function getAdvancementIconClass(entry) {
    const value = normalizeAdvancementLevel(entry);
    if (value === 'Qualifier') return 'fa-solid fa-flag';
    if (value === 'Regional') return 'fa-solid fa-map-location-dot';
    if (value === 'Worlds') return 'fa-solid fa-globe';
    return 'fa-solid fa-flag-checkered';
  }

  function getAdvancementToneClass(entry) {
    const value = normalizeAdvancementLevel(entry);
    if (value === 'Qualifier') return 'qualifier';
    if (value === 'Regional') return 'regional';
    if (value === 'Worlds') return 'worlds';
    return 'other';
  }

  function activateMarkerLabel(teamName) {
    document.querySelectorAll('.marker-label').forEach(el => {
      el.classList.add('marker-label--dim');
      el.classList.remove('marker-label--active');
    });
  }

  function renderPagination(totalTeams) {
    const totalPages = Math.max(1, Math.ceil(totalTeams / teamsPerPage));
    currentPage = Math.min(Math.max(currentPage, 1), totalPages);
    paginationEl.replaceChildren();
    paginationEl.hidden = totalPages <= 1;
    if (totalPages <= 1) return;

    const makeButton = (label, page, options = {}) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = `teams-page-button${options.current ? ' is-current' : ''}`;
      button.textContent = label;
      button.disabled = Boolean(options.disabled);
      if (options.current) button.setAttribute('aria-current', 'page');
      button.setAttribute('aria-label', options.ariaLabel || `Go to page ${page}`);
      button.addEventListener('click', () => {
        currentPage = page;
        applySearch();
        listViewport.scrollTo({ top: 0, behavior: 'smooth' });
      });
      return button;
    };

    paginationEl.appendChild(makeButton('Previous', currentPage - 1, {
      disabled: currentPage === 1,
      ariaLabel: 'Previous team page'
    }));

    const pageNumbers = [];
    for (let page = 1; page <= totalPages; page++) {
      if (totalPages <= 7 || page === 1 || page === totalPages || Math.abs(page - currentPage) <= 1) {
        pageNumbers.push(page);
      }
    }
    pageNumbers.forEach((page, index) => {
      if (index && page - pageNumbers[index - 1] > 1) {
        const ellipsis = document.createElement('span');
        ellipsis.className = 'teams-page-ellipsis';
        ellipsis.textContent = '…';
        ellipsis.setAttribute('aria-hidden', 'true');
        paginationEl.appendChild(ellipsis);
      }
      paginationEl.appendChild(makeButton(String(page), page, { current: page === currentPage }));
    });

    paginationEl.appendChild(makeButton('Next', currentPage + 1, {
      disabled: currentPage === totalPages,
      ariaLabel: 'Next team page'
    }));
  }

  function applySearch(options = {}) {
    if (options.resetPage) currentPage = 1;
    const query = searchInput.value.trim().toLowerCase();
    const searchScope = searchInput.dataset.searchScope || 'all';
    const selectedProgram = programFilter ? programFilter.value : 'All';
    const selectedAwards = awardsFilter ? awardsFilter.value : 'all';
    const selectedYears = yearsFilter ? yearsFilter.value : 'all';
    const selectedAdvancement = advancementFilter ? advancementFilter.value : 'all';
    const selectedDistance = distanceFilter ? distanceFilter.value : 'all';
    const normalizedSelectedAdvancement = normalizeAdvancementLevel(selectedAdvancement);
    const matchingCards = [];

    Object.values(window._teamCards).forEach(card => {
      const matchesProgram = selectedProgram === 'All' || card.dataset.program === selectedProgram;
      const hasAwards = card.dataset.hasAwards === 'true';
      const yearsInProgram = Number(card.dataset.yearsInProgram || '');
      const advancementLevels = String(card.dataset.advancementLevels || '')
        .split('|')
        .map(normalizeAdvancementLevel)
        .filter(Boolean);
      const distanceKm = card.dataset.distanceKm ? Number(card.dataset.distanceKm) : NaN;
      const matchesAwards = selectedAwards === 'all'
        || (selectedAwards === 'has-awards' && hasAwards)
        || (selectedAwards === 'no-awards' && !hasAwards);
      const matchesYears = selectedYears === 'all'
        || (selectedYears === 'new-team' && card.dataset.isNewTeam === 'true')
        || (selectedYears === 'unknown' && !Number.isFinite(yearsInProgram))
        || (selectedYears === 'rookie' && Number.isFinite(yearsInProgram) && yearsInProgram >= 1 && yearsInProgram <= 2)
        || (selectedYears === 'mid' && Number.isFinite(yearsInProgram) && yearsInProgram >= 3 && yearsInProgram <= 5)
        || (selectedYears === 'veteran' && Number.isFinite(yearsInProgram) && yearsInProgram >= 6);
      const matchesAdvancement = selectedAdvancement === 'all'
        || (selectedAdvancement === 'unknown' && advancementLevels.length === 0)
        || advancementLevels.includes(normalizedSelectedAdvancement);
      const maxDistanceKm = distanceThresholdToKm(Number(selectedDistance), distanceUnitPreference);
      const matchesDistance = selectedDistance === 'all'
        || (Number.isFinite(distanceKm) && Number.isFinite(maxDistanceKm) && distanceKm <= maxDistanceKm);
      const searchableText = searchScope === 'team' ? card.dataset.teamSearch : card.dataset.search;
      const matches = matchesProgram && matchesAwards && matchesYears && matchesAdvancement && matchesDistance && (!query || searchableText.includes(query));
      card.dataset.matchesFilter = matches ? 'true' : 'false';
      if (matches) matchingCards.push(card);

      setTeamLayerVisible(card.dataset.team, matches);
    });

    const visibleCount = matchingCards.length;
    const totalPages = Math.max(1, Math.ceil(visibleCount / teamsPerPage));
    currentPage = Math.min(currentPage, totalPages);
    const pageStart = (currentPage - 1) * teamsPerPage;
    const pageEnd = pageStart + teamsPerPage;
    Object.values(window._teamCards).forEach(card => { card.hidden = true; });
    matchingCards.forEach((card, index) => {
      card.hidden = index < pageStart || index >= pageEnd;
    });

    resultCount.textContent = `${visibleCount} team${visibleCount === 1 ? '' : 's'}`;
    emptyEl.hidden = visibleCount !== 0;
    renderPagination(visibleCount);
    if (options.resetPage) listViewport.scrollTop = 0;
  }

  function highlightTeamCard(teamName, options = {}) {
    const card = window._teamCards[teamName];
    if (!card) return;

    if (card.hidden) {
      const matchingCards = Object.values(window._teamCards)
        .filter(item => item.dataset.matchesFilter === 'true');
      const cardIndex = matchingCards.indexOf(card);
      if (cardIndex >= 0) {
        currentPage = Math.floor(cardIndex / teamsPerPage) + 1;
        applySearch();
      }
    }

    Object.values(window._teamCards).forEach(item => item.classList.remove('is-active'));
    card.classList.add('is-active');

    if (options.scroll) {
      card.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }

  function focusTeam(teamName, options = {}) {
    const marker = (window._teamMarkers || {})[teamName];
    const map = window._teamsMapInstance;

    highlightTeamCard(teamName, { scroll: Boolean(options.scroll) });
    activateMarkerLabel(teamName);

    if (!marker || !map) return false;

    try {
      if (marker.getLatLng && map.setView) {
        map.setView(marker.getLatLng(), Math.max(map.getZoom(), options.zoom || 12));
      } else if (marker.getPosition && map.panTo) {
        map.panTo(marker.getPosition());
        const zoom = Math.max(map.getZoom(), options.zoom || 14);
        map.setZoom(zoom);
      }

      if (window._infoWindowTimer) {
        clearTimeout(window._infoWindowTimer);
        window._infoWindowTimer = null;
        // Ensure it's opaque if we interrupted a fade
        const iw = document.querySelector('.gm-style-iw-t');
        if (iw) iw.style.opacity = '1';
      }

      if (options.openPopup !== false && marker.openPopup) {
        marker.openPopup();
      } else if (options.openPopup !== false && window._infoWindow) {
        window._infoWindow.setContent(marker.popupContent);
        window._infoWindow.setPosition(marker.getPosition());
        window._infoWindow.open({ map, shouldFocus: false });
      }
      return true;
    } catch (e) {
      return false;
    }
  }

  function focusTeamWhenReady(teamName, options = {}) {
    if (focusTeam(teamName, options)) return;

    let attempts = 0;
    const iv = setInterval(() => {
      attempts++;
      if (focusTeam(teamName, options) || attempts > 20) {
        clearInterval(iv);
      }
    }, 150);
  }

  searchInput.addEventListener('input', (event) => {
    if (event.isTrusted) delete searchInput.dataset.searchScope;
    applySearch({ resetPage: true });
  });
  function closeFilterDropdown() {
    if (!filterButton || !filterDropdown || !filterMenu) return;
    filterButton.setAttribute('aria-expanded', 'false');
    filterDropdown.hidden = true;
    filterMenu.classList.remove('is-open');
  }

  function openFilterDropdown() {
    if (!filterButton || !filterDropdown || !filterMenu) return;
    filterButton.setAttribute('aria-expanded', 'true');
    filterDropdown.hidden = false;
    filterMenu.classList.add('is-open');
  }

  function resetFilters() {
    if (searchInput) searchInput.value = '';
    if (programFilter) programFilter.value = 'All';
    if (awardsFilter) awardsFilter.value = 'all';
    if (yearsFilter) yearsFilter.value = 'all';
    if (advancementFilter) advancementFilter.value = 'all';
    if (distanceFilter) distanceFilter.value = 'all';
    applySearch({ resetPage: true });
  }

  [programFilter, awardsFilter, yearsFilter, advancementFilter, distanceFilter].filter(Boolean).forEach((filterEl) => {
    filterEl.addEventListener('change', () => {
      applySearch({ resetPage: true });
    });
  });
  if (clearFiltersButton) {
    clearFiltersButton.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      resetFilters();
    });
  }
  if (filterButton && filterDropdown && filterMenu) {
    filterButton.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      const expanded = filterButton.getAttribute('aria-expanded') === 'true';
      if (expanded) {
        closeFilterDropdown();
      } else {
        openFilterDropdown();
      }
    });

    document.addEventListener('click', (event) => {
      if (filterMenu.contains(event.target)) return;
      closeFilterDropdown();
    });
  }

  function setTeamLayerVisible(teamName, visible) {
    const layerSet = (window._teamMapLayers || {})[teamName];
    const marker = (window._teamMarkers || {})[teamName];
    const map = window._teamsMapInstance;
    if (layerSet) {
      layerSet.visible = visible;
      if (typeof window._updateTeamZoomNotifiers === 'function') {
        window._updateTeamZoomNotifiers();
      } else {
        if (layerSet.notifier && layerSet.notifier.setVisible) layerSet.notifier.setVisible(visible);
        if (layerSet.privacyCircle && layerSet.privacyCircle.setVisible) layerSet.privacyCircle.setVisible(false);
      }
      return;
    }

    if (!marker) return;

    if (marker.setVisible) {
      marker.setVisible(visible);
      return;
    }

    if (map && map.hasLayer && map.addLayer && map.removeLayer) {
      if (visible && !map.hasLayer(marker)) {
        marker.addTo(map);
      } else if (!visible && map.hasLayer(marker)) {
        map.removeLayer(marker);
      }
    }
  }

  function renderExpandableHistorySection({ title, iconClass, entries, sectionKey, sourceLink }) {
    const visibleEntries = entries.slice(0, 2);
    const hiddenEntries = entries.slice(2);
    const hasHiddenEntries = hiddenEntries.length > 0;
    const renderEntry = (entry, hidden = false) => {
      const displayEntry = sectionKey === 'awards' ? formatAwardHistoryDisplayEntry(entry) : entry;
      const icon = sectionKey === 'advancement' ? getAdvancementIconClass(entry) : iconClass;
      const toneClass = sectionKey === 'advancement' ? ` team-history-item--${getAdvancementToneClass(entry)}` : ' team-history-item--award';
      const meta = sectionKey === 'advancement' ? normalizeAdvancementLevel(entry) : 'Award';
      return `
        <li class="team-history-item${toneClass}"${hidden ? ' hidden data-history-hidden="true"' : ''}>
          <span class="team-history-entry">
            <span class="team-history-icon" aria-hidden="true"><i class="${escapeHTML(icon)}"></i></span>
            <span class="team-history-text">${escapeHTML(displayEntry)}</span>
            <span class="team-history-meta">${escapeHTML(meta)}</span>
          </span>
        </li>
      `;
    };

    return `
      <div class="team-card-award-history team-history-section" data-history-section="${escapeHTML(sectionKey)}">
        <strong><i class="${escapeHTML(iconClass)}" aria-hidden="true"></i> ${escapeHTML(title)}</strong>
        <ul class="team-history-list">
          ${visibleEntries.map((entry) => renderEntry(entry)).join('')}
          ${hiddenEntries.map((entry) => renderEntry(entry, true)).join('')}
        </ul>
        ${hasHiddenEntries ? `
          <button type="button" class="team-history-toggle" aria-expanded="false" aria-label="Show all ${escapeHTML(title).toLowerCase()}" data-history-toggle="false">
            <span class="team-history-toggle-icon" aria-hidden="true">...</span>
          </button>
        ` : ''}
        ${sourceLink ? `
          <a class="team-history-source-link" href="${escapeHTML(sourceLink.href)}" target="_blank" rel="noopener noreferrer">
            <i class="fa-solid fa-arrow-up-right-from-square" aria-hidden="true"></i>
            ${escapeHTML(sourceLink.label)}
          </a>
        ` : ''}
      </div>
    `;
  }

  function renderTeamReportMenu(team, teamName) {
    const teamId = String((team && (team.id || team._id)) || '');
    if (!teamId) return '';

    return `
      <details class="report-menu team-report-menu">
        <summary class="team-card-icon-button" aria-label="Report ${escapeHTML(teamName)}" title="Report team">
          <i class="fa-regular fa-flag" aria-hidden="true"></i>
        </summary>
        <form class="report-menu-panel" action="/reports" method="POST">
          <input type="hidden" name="targetType" value="team">
          <input type="hidden" name="targetId" value="${escapeHTML(teamId)}">
          <input type="hidden" name="returnTo" value="/teams-nearby">
          <label>
            Why are you reporting this team?
            <select name="reason" required>
              <option value="">Choose a reason</option>
              <option value="spam_or_scam">Spam or scam</option>
              <option value="inappropriate_content">Inappropriate content or behavior</option>
              <option value="impersonation">Impersonation or false information</option>
              <option value="privacy_or_safety">Privacy or safety concern</option>
              <option value="other">Other</option>
            </select>
          </label>
          <label>
            Additional details (optional)
            <textarea name="details" rows="3" maxlength="1000" placeholder="Tell us what happened"></textarea>
          </label>
          <button type="submit" class="btn btn-tertiary report-submit-button">Submit report</button>
        </form>
      </details>
    `;
  }

  orderedTeams.forEach(team => {
    const teamLat = Number(team.lat);
    const teamLon = Number(team.lon);
    const hasCoordinates = Number.isFinite(teamLat) && Number.isFinite(teamLon);
    const dist = userCoords && hasCoordinates ? haversineDistance(userCoords.lat, userCoords.lon, teamLat, teamLon) : null;
    const teamName = String(team.name || 'Unnamed team');
    const programLabel = String(team.program || 'FTC');
    const isNewTeam = Boolean(team.isNewTeam);
    const isRecruiting = isTeamRecruiting(team);
    const countryApplicationState = getCountryApplicationState(team);
    const teamNumber = isNewTeam
      ? 'New Team'
      : (team.teamNumber ? `${programLabel} ${team.teamNumber}` : `${programLabel} team`);
    const location = String(team.location || '').trim();
    const regionLabel = String(team.competitionRegionLabel || team.regionLabel || '').trim();
    const notes = String(team.notes || '').trim();
    const awards = String(team.awards || '').trim();
    const awardHistory = Array.isArray(team.awardHistory) ? team.awardHistory.filter(Boolean) : [];
    const yearsInProgram = Number(team.yearsInProgram);
    const advancementLevels = Array.isArray(team.advancementLevels) ? team.advancementLevels.map(normalizeAdvancementLevel).filter(Boolean) : [];
    const advancementHistory = Array.isArray(team.advancementHistory) ? team.advancementHistory.filter(Boolean) : [];
    const teamContact = String(team.contact || '').trim();
    const scoutingUrl = getTeamScoutingUrl(team);
    const scoutingLabel = programLabel === 'FTC' ? 'View on FTC Scout' : 'View on The Blue Alliance';
    const advancementEntries = advancementHistory.length
      ? advancementHistory.map((entry, index) => formatAdvancementEntry(entry, advancementLevels, index))
      : advancementLevels;
    const teamRequirementsText = getTeamRequirementsText(notes);
    const distanceData = Number.isFinite(dist) ? formatDistance(dist, distanceUnitPreference) : null;

    const card = document.createElement('div');
    card.className = 'team-card';
    card.classList.add(isRecruiting ? 'team-card--recruiting' : 'team-card--not-recruiting');
    // attach team name to the DOM card for easy lookup from marker events
    card.dataset.team = teamName;
    card.dataset.program = programLabel;
    card.dataset.isNewTeam = isNewTeam ? 'true' : 'false';
    card.dataset.recruiting = isRecruiting ? 'true' : 'false';
    card.dataset.hasAwards = awards ? 'true' : 'false';
    card.dataset.yearsInProgram = Number.isFinite(yearsInProgram) ? String(yearsInProgram) : '';
    card.dataset.advancementLevels = advancementLevels.join('|');
    card.dataset.regionLabel = regionLabel;
    card.dataset.distanceKm = Number.isFinite(dist) ? String(dist) : '';
    card.dataset.teamSearch = `${teamName} ${teamNumber}`.toLowerCase();
    card.dataset.search = `${teamName} ${teamNumber} ${location} ${regionLabel} ${notes} ${awards} ${awardHistory.join(' ')} ${advancementLevels.join(' ')} ${advancementHistory.join(' ')}`.toLowerCase();
    card.innerHTML = firstStartTrustedTypesPolicy.createHTML(`
      <div class="team-card-head">
        <div class="team-card-heading">
          <h3 class="team-card-title">${escapeHTML(teamName)}</h3>
          <span class="team-card-label${isRecruiting ? '' : ' team-card-label--not-recruiting'}">${escapeHTML(teamNumber)}${regionLabel ? ` · ${escapeHTML(regionLabel)}` : ''}</span>
          <span class="team-card-status-row">
            <span class="team-card-status-pill${isRecruiting ? ' team-card-status-pill--recruiting' : ' team-card-status-pill--not-recruiting'}"><i class="fa-solid ${isRecruiting ? 'fa-people-group' : 'fa-ban'}" aria-hidden="true"></i>${escapeHTML(getTeamRecruitingLabel(team))}</span>
            ${isNewTeam
              ? '<span class="team-card-status-pill team-card-status-pill--new-team"><i class="fa-solid fa-seedling" aria-hidden="true"></i>New team</span>'
              : (team.verified ? '<span class="team-card-status-pill team-card-status-pill--verified"><i class="fa-solid fa-circle-check" aria-hidden="true"></i>Verified</span>' : '')}
          </span>
        </div>
        <div class="team-card-toolbar">
          ${renderTeamReportMenu(team, teamName)}
          <button class="btn btn-link goto-marker team-card-icon-button" title="Show on map" aria-label="Show ${escapeHTML(teamName)} on map" data-team="${escapeHTML(teamName)}"><i class="fa-solid fa-map-pin"></i></button>
          <button class="btn btn-link toggle-details team-card-icon-button" aria-expanded="false" aria-label="Toggle details"><i class="fa-solid fa-chevron-down"></i></button>
        </div>
      </div>
      <div class="team-details-content" style="margin-top: 12px; max-height: 0; overflow: hidden; opacity: 0; transition: max-height 260ms ease, opacity 200ms ease;">
        ${teamContact ? `<p class="team-card-contact">Contact <a href="mailto:${escapeHTML(teamContact)}">${escapeHTML(teamContact)}</a></p>` : '<p class="team-card-contact">Contact not set.</p>'}
        ${(location || regionLabel) ? `<p class="team-card-meta">${escapeHTML([location, regionLabel].filter(Boolean).join(' · '))}</p>` : ''}
        ${scoutingUrl ? `
          <p class="team-card-source">
            <a href="${escapeHTML(scoutingUrl)}" target="_blank" rel="noopener noreferrer">
              <i class="fa-solid fa-arrow-up-right-from-square" aria-hidden="true"></i>
              ${escapeHTML(scoutingLabel)}
            </a>
          </p>
        ` : ''}
        ${distanceData ? `<p class="team-distance"><span>Distance</span><strong>${distanceData.label} away</strong></p>` : ''}
        ${Number.isFinite(yearsInProgram) ? `
          <div class="team-card-stats">
            <div class="team-card-stat">
              <span class="team-card-stat-icon" aria-hidden="true">
                <i class="${yearsInProgram === 0 ? 'fa-solid fa-seedling' : 'fa-regular fa-calendar'}"></i>
              </span>
              <span class="team-card-stat-text">${yearsInProgram === 0 ? 'New Team Forming' : `${escapeHTML(String(yearsInProgram))} year${yearsInProgram === 1 ? '' : 's'} in program`}</span>
            </div>
          </div>
        ` : ''}
        <div class="team-card-requirements">
          <div class="team-card-requirements-head">
            <span class="team-card-requirements-icon" aria-hidden="true"><i class="fa-solid fa-list-check"></i></span>
            <span class="team-card-requirements-title">Team Requirements</span>
          </div>
          <p class="team-card-requirements-text">${escapeHTML(teamRequirementsText)}</p>
        </div>
        ${awardHistory.length ? `
          ${renderExpandableHistorySection({
            title: 'Awards achieved',
            iconClass: 'fa-solid fa-medal',
            entries: awardHistory,
            sectionKey: 'awards'
          })}
        ` : ''}
        ${advancementEntries.length ? `
          ${renderExpandableHistorySection({
            title: 'Competition History',
            iconClass: 'fa-solid fa-flag-checkered',
            entries: advancementEntries,
            sectionKey: 'advancement',
            sourceLink: scoutingUrl ? { href: scoutingUrl, label: scoutingLabel } : null
          })}
        ` : ''}
        <div class="team-actions">
          <button class="btn btn-primary send-btn"${!isRecruiting || countryApplicationState.hasTeam || countryApplicationState.outsideCountry || countryApplicationState.outsideRegion ? ' disabled' : ''}>${!isRecruiting ? 'Not Recruiting' : countryApplicationState.hasTeam ? 'Already on a Team' : countryApplicationState.needsCountry ? 'Add Country to Apply' : countryApplicationState.needsRegion ? 'Add State or Region to Apply' : countryApplicationState.outsideCountry ? 'Outside Your Country' : countryApplicationState.outsideRegion ? 'Outside Your State/Region' : 'Send My Info'}</button>
        </div>
      </div>
    `);
    window._teamCards[teamName] = card;

    const sendBtn = card.querySelector('.send-btn');
    if (sendBtn) sendBtn.addEventListener('click', (e) => { e.stopPropagation(); sendToTeam(team); });

    const reportMenu = card.querySelector('.report-menu');
    if (reportMenu) {
      reportMenu.addEventListener('click', event => event.stopPropagation());
      reportMenu.addEventListener('toggle', () => {
        card.classList.toggle('report-menu-open', reportMenu.open);
      });
    }

    const gotoBtn = card.querySelector('.goto-marker');
    if (gotoBtn) gotoBtn.addEventListener('click', event => {
      event.stopPropagation();
      focusTeamWhenReady(teamName, { openPopup: true, zoom: 14 });
    });

    const toggleBtn = card.querySelector('.toggle-details');
    const detailsContent = card.querySelector('.team-details-content');
    const historyToggleButtons = card.querySelectorAll('.team-history-toggle');
    // start collapsed by default for a compact list view
    card.classList.add('collapsed');
    if (detailsContent) {
      // prepare for animated collapse via max-height (use display:block so scrollHeight is measurable)
      detailsContent.style.display = 'block';
      detailsContent.style.maxHeight = '0px';
      detailsContent.style.opacity = '0';
      detailsContent.style.overflow = 'hidden';
      detailsContent.style.transition = 'max-height 260ms ease, opacity 200ms ease';
    }

    historyToggleButtons.forEach((button) => {
      button.addEventListener('click', event => {
        event.stopPropagation();
        const section = button.closest('.team-history-section');
        if (!section) return;
        const isExpanded = button.getAttribute('aria-expanded') === 'true';
        const hiddenItems = section.querySelectorAll('li[data-history-hidden="true"]');

        hiddenItems.forEach((item) => {
          item.hidden = isExpanded;
        });

        const nextExpanded = !isExpanded;
        button.setAttribute('aria-expanded', String(nextExpanded));
        button.setAttribute('data-history-toggle', String(nextExpanded));
        const icon = button.querySelector('.team-history-toggle-icon');
        if (icon) {
          icon.textContent = nextExpanded ? '↑' : '...';
        }

        if (card.classList.contains('expanded') && detailsContent) {
          requestAnimationFrame(() => {
            detailsContent.style.maxHeight = detailsContent.scrollHeight + 'px';
          });
        }
      });
    });

    if (toggleBtn && detailsContent) {
      toggleBtn.addEventListener('click', event => {
        event.stopPropagation();
        const isOpen = card.classList.toggle('expanded');
        if (isOpen) {
          card.classList.remove('collapsed');
          toggleBtn.setAttribute('aria-expanded', 'true');
          detailsContent.style.maxHeight = detailsContent.scrollHeight + 'px';
          detailsContent.style.opacity = '1';
          setTimeout(() => {
            if (card.classList.contains('expanded')) detailsContent.style.maxHeight = 'none';
          }, 280);
        } else {
          card.classList.add('collapsed');
          toggleBtn.setAttribute('aria-expanded', 'false');
          detailsContent.style.maxHeight = detailsContent.scrollHeight + 'px';
          detailsContent.style.opacity = '0';
          requestAnimationFrame(() => { detailsContent.style.maxHeight = '0px'; });
        }
      });

      // allow clicking the card head to toggle as well (but ignore goto/toggle clicks)
      const head = card.querySelector('.team-card-head');
      if (head) {
        head.addEventListener('click', (e) => {
          if (e.target.closest('.goto-marker') || e.target.closest('.toggle-details') || e.target.closest('.report-menu')) return;
          toggleBtn.click();
        });
      }
    }

    let hoverFocusTimer = null;
    card.addEventListener('mouseenter', (event) => {
      if (event.target.closest('.goto-marker') || event.target.closest('.toggle-details') || event.target.closest('.send-btn') || event.target.closest('.report-menu')) return;
      hoverFocusTimer = setTimeout(() => {
        focusTeamWhenReady(teamName, { openPopup: true, zoom: 14, scroll: true });
      }, 2000);
    });

    card.addEventListener('mouseleave', () => {
      if (hoverFocusTimer) {
        clearTimeout(hoverFocusTimer);
        hoverFocusTimer = null;
      }
    });

    // keep legacy behavior: use goto button to focus/open popup

    listEl.appendChild(card);
  });
  applySearch();

  // Initialize Google Maps when its async loader is ready.
  function tryInitMap() {
    if (window._teamsMapRenderVersion !== mapRenderVersion) return;
    if (!window.__GOOGLE_MAPS_ENABLED__) {
      mapEl.classList.add('teams-map-unavailable');
      mapEl.textContent = 'Google Maps is not configured. Add GOOGLE_MAPS_API_KEY to enable the team map.';
      return;
    }
    if (!window.google || !google.maps || !google.maps.Map) {
      setTimeout(tryInitMap, 200);
      return;
    }

    Object.values(window._teamMapLayers || {}).forEach(layerSet => {
      [layerSet.notifier, layerSet.privacyCircle].forEach(layer => {
        if (layer && layer.setMap) layer.setMap(null);
      });
    });
    if (window._userLocationMarker && window._userLocationMarker.setMap) {
      window._userLocationMarker.setMap(null);
    }
    if (window._infoWindow) window._infoWindow.close();
    mapEl.classList.remove('teams-map-unavailable');
    mapEl.replaceChildren();

    // Keep the simplified styling on the road/terrain maps, but let Google's
    // hybrid imagery render its complete built-in label layer.
    const roadmapStyles = [
      { featureType: 'poi', elementType: 'labels', stylers: [{ visibility: 'off' }] },
      { featureType: 'transit', elementType: 'labels', stylers: [{ visibility: 'off' }] }
    ];
    const map = new google.maps.Map(mapEl, {
      center: { lat: 39.5, lng: -98.35 },
      zoom: 4,
      mapTypeId: google.maps.MapTypeId.ROADMAP,
      clickableIcons: false,
      fullscreenControl: true,
      mapTypeControl: false,
      cameraControl: true,
      zoomControl: true,
      scaleControl: true,
      streetViewControl: true,
      rotateControl: true,
      tiltInteractionEnabled: true,
      headingInteractionEnabled: true,
      gestureHandling: 'cooperative',
      styles: roadmapStyles
    });
    const mapTypeControl = document.createElement('div');
    mapTypeControl.className = 'google-map-type-control';
    mapTypeControl.setAttribute('role', 'group');
    mapTypeControl.setAttribute('aria-label', 'Map display');

    const mapButton = document.createElement('button');
    mapButton.type = 'button';
    mapButton.className = 'google-map-type-button';
    mapButton.textContent = 'Map';
    mapButton.addEventListener('click', () => map.setMapTypeId(google.maps.MapTypeId.ROADMAP));

    const satelliteButton = document.createElement('button');
    satelliteButton.type = 'button';
    satelliteButton.className = 'google-map-type-button';
    satelliteButton.textContent = 'Satellite';
    satelliteButton.addEventListener('click', () => {
      // Hybrid is Google's satellite imagery with place and road labels enabled.
      map.setMapTypeId(google.maps.MapTypeId.HYBRID);
    });

    const hybridButton = document.createElement('button');
    hybridButton.type = 'button';
    hybridButton.className = 'google-map-type-button';
    hybridButton.textContent = 'Hybrid';
    hybridButton.addEventListener('click', () => map.setMapTypeId(google.maps.MapTypeId.HYBRID));

    /* Legacy menu nodes are retained only for compatibility with existing map instances. */
    const moreButton = document.createElement('button');
    moreButton.type = 'button';
    moreButton.className = 'google-map-type-more';
    moreButton.textContent = '▾';
    moreButton.setAttribute('aria-label', 'More map types');
    moreButton.setAttribute('aria-haspopup', 'menu');
    moreButton.setAttribute('aria-expanded', 'false');

    const mapTypeMenu = document.createElement('div');
    mapTypeMenu.className = 'google-map-type-menu';
    mapTypeMenu.setAttribute('role', 'menu');
    mapTypeMenu.hidden = true;

    const terrainButton = document.createElement('button');
    terrainButton.type = 'button';
    terrainButton.className = 'google-map-type-button';
    terrainButton.textContent = 'Terrain';
    terrainButton.setAttribute('role', 'menuitemradio');
    terrainButton.addEventListener('click', () => {
      map.setMapTypeId(google.maps.MapTypeId.TERRAIN);
      mapTypeMenu.hidden = true;
      moreButton.setAttribute('aria-expanded', 'false');
    });

    moreButton.addEventListener('click', () => {
      const willOpen = mapTypeMenu.hidden;
      mapTypeMenu.hidden = !willOpen;
      moreButton.setAttribute('aria-expanded', String(willOpen));
    });
    moreButton.addEventListener('keydown', event => {
      if (event.key === 'Escape') {
        mapTypeMenu.hidden = true;
        moreButton.setAttribute('aria-expanded', 'false');
        moreButton.focus();
      }
    });

    mapTypeMenu.appendChild(terrainButton);
    // Keep the compact two-option control while Satellite continues to use
    // Google's labeled HYBRID imagery internally.
    mapTypeControl.append(mapButton, satelliteButton);
    map.controls[google.maps.ControlPosition.TOP_LEFT].push(mapTypeControl);

    const syncMapTypeControl = () => {
      const activeType = map.getMapTypeId();
      // Never leave the map in unlabeled SATELLITE mode. HYBRID is the
      // standard Google satellite view with roads and place names overlaid.
      if (activeType === google.maps.MapTypeId.SATELLITE) {
        map.setMapTypeId(google.maps.MapTypeId.HYBRID);
        return;
      }
      const mapIsActive = activeType === google.maps.MapTypeId.ROADMAP
        || activeType === google.maps.MapTypeId.TERRAIN;
      const satelliteIsActive = activeType === google.maps.MapTypeId.HYBRID;
      map.setOptions({ styles: satelliteIsActive ? null : roadmapStyles });
      mapButton.classList.toggle('is-active', mapIsActive);
      satelliteButton.classList.toggle('is-active', satelliteIsActive);
      hybridButton.classList.remove('is-active');
      terrainButton.classList.toggle('is-active', activeType === google.maps.MapTypeId.TERRAIN);
      mapButton.setAttribute('aria-pressed', String(mapIsActive));
      satelliteButton.setAttribute('aria-pressed', String(satelliteIsActive));
      hybridButton.setAttribute('aria-pressed', 'false');
      terrainButton.setAttribute('aria-checked', String(activeType === google.maps.MapTypeId.TERRAIN));
    };
    map.addListener('maptypeid_changed', syncMapTypeControl);
    map.addListener('click', () => {
      mapTypeMenu.hidden = true;
      moreButton.setAttribute('aria-expanded', 'false');
    });
    syncMapTypeControl();
    const updateTeamZoomNotifiers = () => {
      const zoom = Number(map.getZoom());
      const compact = zoom <= 7;
      const showPrivacyCircle = zoom >= 14;
      Object.values(window._teamMapLayers || {}).forEach(layerSet => {
        if (!layerSet.notifier) return;
        layerSet.notifier.setCompact(compact);
        layerSet.notifier.setVisible(layerSet.visible !== false);
        if (layerSet.privacyCircle) {
          layerSet.privacyCircle.setVisible(layerSet.visible !== false && showPrivacyCircle);
        }
      });
    };
    window._updateTeamZoomNotifiers = updateTeamZoomNotifiers;

    window._teamsMapInstance = map;
    window._infoWindowTimer = null;
    window._pinnedTeamPopup = null;
    window._teamMapLayers = {};
    window._teamMarkers = {};
    window._userLocationMarker = null;
    window._infoWindow = new google.maps.InfoWindow({
      maxWidth: 340,
      // Leave the full team pin visible directly below the popup pointer.
      pixelOffset: new google.maps.Size(0, -32)
    });

    const bounds = new google.maps.LatLngBounds();
    window._userLocationMarker = createUserLocationMarker(map, userCoords, bounds);
    const GoogleHtmlMarker = getGoogleHtmlMarkerClass();

    teams.forEach(team => {
      const teamLat = Number(team.lat);
      const teamLon = Number(team.lon);
      if (!Number.isFinite(teamLat) || !Number.isFinite(teamLon)) return;
      if (team.registered === false) return;

      const teamName = String(team.name || 'Unnamed team');
      const programLabel = String(team.program || 'FTC');
      const isNewTeam = Boolean(team.isNewTeam);
      const isRecruiting = isTeamRecruiting(team);
      const countryApplicationState = getCountryApplicationState(team);
      const dist = userCoords ? haversineDistance(userCoords.lat, userCoords.lon, teamLat, teamLon) : null;
      const distanceData = Number.isFinite(dist) ? formatDistance(dist, distanceUnitPreference) : null;
      const location = String(team.location || '').trim();
      const teamContact = String(team.contact || '').trim();

      const popupContent = `
        <div class="google-team-popup google-team-popup--single">
          <button type="button" class="google-team-popup-close" aria-label="Close team information">&times;</button>
          <h4>${escapeHTML(teamName)}</h4>
          ${isNewTeam ? '<p class="google-team-popup-subtitle">New Team</p>' : (team.teamNumber ? `<p class="google-team-popup-subtitle">${escapeHTML(programLabel)} ${escapeHTML(team.teamNumber)}</p>` : '')}
          ${location ? `<p class="google-team-popup-detail">${escapeHTML(location)}</p>` : ''}
          <p class="google-team-popup-status${isRecruiting ? '' : ' is-inactive'}">${getTeamRecruitingLabel(team)}</p>
          <p class="google-team-popup-contact"><strong>Contact</strong><span>${teamContact ? `<a href="mailto:${escapeHTML(teamContact)}">${escapeHTML(teamContact)}</a>` : 'Contact email not listed'}</span></p>
          ${distanceData ? `<p class="google-team-popup-distance">${distanceData.label} away</p>` : ''}
          <button class="popup-send-btn btn btn-primary" data-team="${escapeHTML(teamName)}"${!isRecruiting || countryApplicationState.hasTeam || countryApplicationState.outsideCountry || countryApplicationState.outsideRegion ? ' disabled' : ''}>${!isRecruiting ? 'Not Recruiting' : countryApplicationState.hasTeam ? 'Already on a Team' : countryApplicationState.needsCountry ? 'Add Country to Apply' : countryApplicationState.needsRegion ? 'Add State or Region to Apply' : countryApplicationState.outsideCountry ? 'Outside Your Country' : countryApplicationState.outsideRegion ? 'Outside Your State/Region' : 'Send My Info'}</button>
        </div>
      `;

      const position = getPrivacyOffsetPosition(team, teamLat, teamLon);
      let marker;
      const openPopup = () => {
        window._infoWindow.setContent(popupContent);
        window._infoWindow.setPosition(position);
        window._infoWindow.open({ map, shouldFocus: false });
      };
      const closePopup = () => {
        if (!window._pinnedTeamPopup) window._infoWindow.close();
      };
      const beginPopupHover = () => {
        if (window._pinnedTeamPopup) return;
        if (marker.popupHoverTimer) clearTimeout(marker.popupHoverTimer);
        marker.popupHoverTimer = setTimeout(() => {
          marker.popupHoverTimer = null;
          if (!window._pinnedTeamPopup) openPopup();
        }, 1000);
      };
      const endPopupHover = () => {
        if (marker.popupHoverTimer) clearTimeout(marker.popupHoverTimer);
        marker.popupHoverTimer = null;
      };
      const PrivacyOverlay = getGooglePrivacyOverlayClass();
      const privacyCircle = new PrivacyOverlay({
        map,
        position,
        radiusMeters: TEAM_PRIVACY_RADIUS_METERS
      });
      marker = new GoogleHtmlMarker({
        map,
        position,
        title: `${teamName} location`,
        className: 'google-team-marker-overlay',
        html: '<span class="team-zoom-notifier team-zoom-notifier--team" aria-hidden="true"></span>',
        onClick: () => {
          window._pinnedTeamPopup = { teamName, marker };
          focusTeam(teamName, { scroll: true, openPopup: true, zoom: 12 });
        },
        onMouseOver: () => {
          beginPopupHover();
        },
        onMouseOut: () => {
          endPopupHover();
          window._infoWindowTimer = setTimeout(closePopup, 400);
        }
      });
      marker.popupContent = popupContent;
      marker.openPopup = openPopup;
      marker.closePopup = closePopup;

      if (!window._teamMarkers) window._teamMarkers = {};
      window._teamMarkers[teamName] = marker;
      if (!window._teamMapLayers) window._teamMapLayers = {};
      window._teamMapLayers[teamName] = {
        notifier: marker,
        privacyCircle,
        visible: true
      };
      bounds.extend(position);
    });

    if (userCoords && typeof userCoords.lat === 'number' && typeof userCoords.lon === 'number') {
      map.setCenter({ lat: userCoords.lat, lng: userCoords.lon });
      map.setZoom(12);
    } else if (!bounds.isEmpty()) {
      map.fitBounds(bounds, 42);
    }
    updateTeamZoomNotifiers();
    map.addListener('zoom_changed', updateTeamZoomNotifiers);
    map.addListener('idle', updateTeamZoomNotifiers);
    map.addListener('click', () => {
      window._pinnedTeamPopup = null;
      if (window._infoWindowTimer) {
        clearTimeout(window._infoWindowTimer);
        window._infoWindowTimer = null;
      }
      window._infoWindow.close();
    });

    window._infoWindow.addListener('domready', () => {
      const btn = document.querySelector('.gm-style-iw .popup-send-btn');
      const popup = document.querySelector('.gm-style-iw .google-team-popup');
      const closeButton = document.querySelector('.gm-style-iw .google-team-popup-close');
      if (closeButton) {
        closeButton.onclick = event => {
          event.preventDefault();
          event.stopPropagation();
          window._pinnedTeamPopup = null;
          window._infoWindow.close();
        };
      }
      if (popup) {
        popup.onmouseenter = () => {
          if (window._infoWindowTimer) {
            clearTimeout(window._infoWindowTimer);
            window._infoWindowTimer = null;
          }
        };
        popup.onmouseleave = () => {
          if (window._pinnedTeamPopup) return;
          window._infoWindowTimer = setTimeout(() => {
            window._infoWindow.close();
            window._infoWindowTimer = null;
          }, 300);
        };
      }
      if (btn) {
        btn.onclick = () => {
          const teamName = btn.getAttribute('data-team');
          const team = teams.find(t => t.name === teamName);
          if (team) sendToTeam(team);
        };
      }
    });
    window._infoWindow.addListener('closeclick', () => {
      window._pinnedTeamPopup = null;
    });

    applySearch({ resetPage: true });
  }

  window.addEventListener('google-maps-ready', tryInitMap, { once: true });
  tryInitMap();
}

function confirmSendInfoToTeam(team) {
  const teamName = String((team && team.name) || 'this team').trim() || 'this team';
  const isNewTeam = Boolean(team && team.isNewTeam);

  return new Promise((resolve) => {
    const existingModal = document.querySelector('[data-send-info-confirm]');
    if (existingModal) existingModal.remove();

    const modal = document.createElement('div');
    modal.className = 'send-info-confirm-backdrop';
    modal.setAttribute('data-send-info-confirm', 'true');
    modal.innerHTML = firstStartTrustedTypesPolicy.createHTML(`
      <section class="send-info-confirm-dialog" role="dialog" aria-modal="true" aria-labelledby="sendInfoConfirmTitle" aria-describedby="sendInfoConfirmText">
        <h2 id="sendInfoConfirmTitle">Send your info?</h2>
        <p id="sendInfoConfirmText">You are sending your information to <strong>${escapeHTML(teamName)}</strong>.</p>
        ${isNewTeam ? '<p class="send-info-confirm-warning"><i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i> This is a new team and has not been verified.</p>' : ''}
        <div class="send-info-confirm-actions">
          <button type="button" class="btn btn-secondary" data-send-info-cancel>Cancel</button>
          <button type="button" class="btn btn-primary" data-send-info-confirm-button>Send Info</button>
        </div>
      </section>
    `);

    const finish = (confirmed) => {
      document.removeEventListener('keydown', handleKeydown);
      modal.remove();
      resolve(confirmed);
    };
    const handleKeydown = (event) => {
      if (event.key === 'Escape') finish(false);
    };

    modal.addEventListener('click', event => {
      if (event.target === modal) finish(false);
    });
    modal.querySelector('[data-send-info-cancel]').addEventListener('click', () => finish(false));
    modal.querySelector('[data-send-info-confirm-button]').addEventListener('click', () => finish(true));
    document.addEventListener('keydown', handleKeydown);
    document.body.appendChild(modal);
    modal.querySelector('[data-send-info-confirm-button]').focus();
  });
}

function initCharacterCounters() {
  document.querySelectorAll('input[name="interests"], textarea[name="experience"]').forEach(field => {
    const maxLength = field.name === 'interests' ? 200 : 500;
    field.maxLength = maxLength;
    let counter = field.parentElement && field.parentElement.querySelector(`[data-character-count-for="${field.name}"]`);
    if (!counter) {
      const wrapper = document.createElement('div');
      wrapper.className = 'character-field';
      field.replaceWith(wrapper);
      wrapper.appendChild(field);
      counter = document.createElement('div');
      counter.className = 'character-count';
      counter.dataset.characterCountFor = field.name;
      counter.setAttribute('aria-live', 'polite');
      wrapper.appendChild(counter);
    }
    const update = () => { counter.textContent = `${field.value.length} / ${maxLength}`; };
    field.addEventListener('input', update);
    update();
  });
}

async function sendToTeam(team) {
  const currentUser = getCurrentUser();
  if (!currentUser) {
    redirectToAuthGate(window.location.pathname || '/teams-nearby', 'Send My Info');
    return;
  }

  const countryApplicationState = getCountryApplicationState(team);
  if (countryApplicationState.hasTeam) {
    alert('Accounts that already belong to or manage a team cannot apply to another team.');
    return;
  }
  if (countryApplicationState.needsCountry || countryApplicationState.needsRegion) {
    window.location.href = '/account/signup-info?back=teams';
    return;
  }
  if (countryApplicationState.outsideCountry) {
    alert('You can only apply to teams in your country.');
    return;
  }
  if (countryApplicationState.outsideRegion) {
    alert('You can only apply to teams in your state or region.');
    return;
  }

  const applicationDetails = await confirmSendInfoToTeam(team);
  if (!applicationDetails) {
    return;
  }

  try {
    const response = await fetch('/api/signups', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        teamId: team && (team.id || team._id)
      })
    });

    const payload = await response.json().catch(() => ({}));
    if (!response.ok) {
      alert(payload && payload.error ? payload.error : 'Unable to save your application right now.');
      if (payload.code === 'PROFILE_GRADE_REQUIRED') {
        window.location.href = '/account/signup-info?back=teams';
      }
      return;
    }

    alert(`Your info was sent to ${team.name || 'the team'}.`);
  } catch (err) {
    alert('Unable to save your application right now.');
    if (err && err.message) {
      console.error('Unable to save your application right now:', err);
    }
    return;
  }
}

function initTeamsPage() {
  const container = document.getElementById('teamsContainer');
  if (!container) return;

  const teams = Array.isArray(window.__TEAMS__)
    ? window.__TEAMS__.map(team => ({
      ...team,
      lat: Number(team.lat),
      lon: Number(team.lon)
    }))
    : [];
  const coords = window.__USER_COORDS__ || null;
  const status = document.getElementById('teamsStatus');
  const zipForm = document.getElementById('zipLocationForm');
  const zipInput = document.getElementById('zipLocationInput');
  const zipMessage = document.getElementById('zipLocationMessage');
  const initialQuery = String(new URLSearchParams(window.location.search).get('q') || '').trim();
  let locationRequestVersion = 0;
  if (!teams.length) {
    status.textContent = 'Team listings are temporarily unavailable. Please try again shortly.';
    renderTeams([], null);
    return;
  }

  status.textContent = 'Loading teams…';

  if (zipInput && initialQuery) {
    zipInput.value = initialQuery;
  }

  const hasInitialCoords = coords
    && Number.isFinite(Number(coords.lat))
    && Number.isFinite(Number(coords.lon));
  // Listings and search must be usable while a location prompt or lookup is
  // pending, including when the browser never answers the permission prompt.
  renderTeams(teams, hasInitialCoords ? coords : null);
  status.textContent = 'Showing recruiting teams';

  function setZipMessage(message, isError = false) {
    if (!zipMessage) return;
    zipMessage.textContent = message || '';
    zipMessage.classList.toggle('is-error', Boolean(isError));
  }

  function hasTeamWithinMiles(referenceCoords, radiusMiles) {
    if (!referenceCoords || typeof referenceCoords.lat !== 'number' || typeof referenceCoords.lon !== 'number') return false;
    const radiusKm = radiusMiles / 0.621371;
    return teams.some(team => (
      team
      && typeof team.lat === 'number'
      && typeof team.lon === 'number'
      && haversineDistance(referenceCoords.lat, referenceCoords.lon, team.lat, team.lon) <= radiusKm
    ));
  }

  function updateLocationStatus(referenceCoords, nearbyMessage) {
    status.textContent = hasTeamWithinMiles(referenceCoords, 100)
      ? nearbyMessage
      : "Sorry, we don't find any registered team at your location";
  }

  function applyTeamNameSearch(query) {
    const normalizedQuery = String(query || '').trim().toLowerCase();
    if (!normalizedQuery) return false;

    const matchingTeams = teams.filter((team) => {
      const teamName = String(team && team.name || '').trim().toLowerCase();
      const teamNumber = String(team && team.teamNumber || '').trim().toLowerCase();
      const programAndNumber = `${String(team && team.program || '').trim()} ${teamNumber}`.trim().toLowerCase();
      return teamName.includes(normalizedQuery)
        || Boolean(teamNumber && (teamNumber === normalizedQuery || programAndNumber.includes(normalizedQuery)));
    });

    if (!matchingTeams.length) return false;

    const teamSearchInput = document.getElementById('teamsSearch');
    if (!teamSearchInput) return false;
    teamSearchInput.dataset.searchScope = 'team';
    teamSearchInput.value = query;
    teamSearchInput.dispatchEvent(new Event('input', { bubbles: true }));
    status.textContent = `Showing ${matchingTeams.length} team${matchingTeams.length === 1 ? '' : 's'} matching “${query}”`;
    setZipMessage('');
    return true;
  }

  async function lookupLocation(query) {
    const trimmed = String(query || '').trim();
    if (!trimmed) {
      throw new Error('Enter a city, county, state, country, or ZIP code.');
    }

    const endpoint = /^\d{5}$/.test(trimmed) ? `/api/geocode-zip?zip=${encodeURIComponent(trimmed)}` : `/api/geocode-location?q=${encodeURIComponent(trimmed)}`;
    const response = await fetch(endpoint, { credentials: 'same-origin' });
    const payload = await response.json().catch(() => ({}));

    if (!response.ok || !payload.ok || !payload.coords) {
      throw new Error(payload.error || 'Could not find that location.');
    }

    const locationCoords = {
      lat: Number(payload.coords.lat),
      lon: Number(payload.coords.lon)
    };

    if (!Number.isFinite(locationCoords.lat) || !Number.isFinite(locationCoords.lon)) {
      throw new Error('Could not find that location.');
    }

    return {
      coords: locationCoords,
      label: payload.displayName || trimmed
    };
  }

  function useDeviceLocation() {
    if (!navigator.geolocation) {
      status.textContent = 'Showing recruiting teams';
      setZipMessage('Device location is unavailable. Search for a location to sort teams by distance.');
      renderTeams(teams, null);
      return;
    }

    status.textContent = 'Requesting your device location…';
    setZipMessage('Allow location access to automatically show the nearest teams.');
    const requestVersion = ++locationRequestVersion;

    navigator.geolocation.getCurrentPosition(
      (position) => {
        if (requestVersion !== locationRequestVersion) return;
        const deviceCoords = {
          lat: Number(position && position.coords && position.coords.latitude),
          lon: Number(position && position.coords && position.coords.longitude)
        };

        if (!Number.isFinite(deviceCoords.lat) || !Number.isFinite(deviceCoords.lon)) {
          status.textContent = 'Showing recruiting teams';
          setZipMessage('Your device did not provide a usable location. Search for a location instead.', true);
          return;
        }

        renderTeams(teams, deviceCoords);
        updateLocationStatus(deviceCoords, 'Showing teams nearest to your device location');
        setZipMessage('Using your device location.');
      },
      (error) => {
        if (requestVersion !== locationRequestVersion) return;
        status.textContent = 'Showing recruiting teams';
        renderTeams(teams, null);
        const permissionDenied = error && error.code === 1;
        setZipMessage(
          permissionDenied
            ? 'Location access was not allowed. Search for a location to sort teams by distance.'
            : 'Your device location is unavailable. Search for a location to sort teams by distance.',
          false
        );
      },
      {
        enableHighAccuracy: true,
        timeout: 20000,
        maximumAge: 0
      }
    );
  }

  if (zipForm && zipInput) {
    zipForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      locationRequestVersion += 1;
      const query = zipInput.value.trim();

      if (!query) {
        setZipMessage('Enter a team name, city, county, state, country, or ZIP code.', true);
        zipInput.focus();
        return;
      }

      if (applyTeamNameSearch(query)) return;

      setZipMessage('Looking up location...');

      try {
        const location = await lookupLocation(query);
        renderTeams(teams, location.coords);
        updateLocationStatus(location.coords, `Showing teams near ${location.label}`);
        setZipMessage('');
      } catch (err) {
        setZipMessage(err && err.message ? err.message : 'Unable to look up that location right now.', true);
      }
    });
  }

  if (initialQuery && !applyTeamNameSearch(initialQuery)) {
    lookupLocation(initialQuery)
      .then((location) => {
        renderTeams(teams, location.coords);
        updateLocationStatus(location.coords, `Showing teams near ${location.label}`);
        setZipMessage('');
      })
      .catch((err) => {
        setZipMessage(err && err.message ? err.message : 'Unable to look up that location right now.', true);
      });
  }

  if (!initialQuery) {
    if (!hasInitialCoords) useDeviceLocation();
  }
}

function initCountryRegionSelects() {
  document.querySelectorAll('[data-country-select]').forEach((countrySelect) => {
    const form = countrySelect.form || countrySelect.closest('form');
    const regionSelect = form && form.querySelector('[data-region-select]');
    if (!regionSelect || countrySelect.dataset.regionBound === 'true') return;
    countrySelect.dataset.regionBound = 'true';
    const serverRenderedOptions = Array.from(regionSelect.options).map((option) => ({
      value: option.value,
      text: option.textContent
    }));

    const replaceOptions = (regions, placeholder) => {
      regionSelect.replaceChildren();
      if (placeholder) {
        const placeholderOption = document.createElement('option');
        placeholderOption.value = '';
        placeholderOption.textContent = placeholder;
        regionSelect.appendChild(placeholderOption);
      }
      regions.forEach((region) => {
        const option = document.createElement('option');
        option.value = region;
        option.textContent = region;
        regionSelect.appendChild(option);
      });
    };

    const loadRegions = async () => {
      const country = String(countrySelect.value || '').trim();
      const currentRegion = String(regionSelect.value || '').trim();
      regionSelect.disabled = true;
      replaceOptions([], country ? 'Loading states or regions…' : 'Select a country first');
      if (!country) return;

      try {
        const response = await fetch(`/api/country-regions?country=${encodeURIComponent(country)}`, { credentials: 'same-origin' });
        const payload = await response.json().catch(() => ({}));
        if (!response.ok || !payload.ok || !Array.isArray(payload.regions)) throw new Error('Unable to load states or regions.');
        replaceOptions(payload.regions, 'Select a state, province, or region');
        regionSelect.disabled = false;
        if (currentRegion && payload.regions.includes(currentRegion)) {
          regionSelect.value = currentRegion;
        }
        if (payload.regions.length === 1 && payload.regions[0] === 'Not applicable') {
          regionSelect.value = payload.regions[0];
        }
      } catch (error) {
        // Keep server-rendered options usable when the enhancement request is
        // unavailable (for example during a brief API/rate-limit failure).
        if (serverRenderedOptions.length > 1) {
          regionSelect.replaceChildren();
          serverRenderedOptions.forEach(({ value, text }) => {
            const option = document.createElement('option');
            option.value = value;
            option.textContent = text;
            regionSelect.appendChild(option);
          });
          regionSelect.disabled = false;
          if (currentRegion) regionSelect.value = currentRegion;
        } else {
          replaceOptions([], 'Unable to load states or regions');
          regionSelect.disabled = true;
        }
      }
    };

    countrySelect.addEventListener('change', loadRegions);
    // Draft restoration and browser autofill can set the country before or
    // after this initializer without dispatching a change event. Hydrate the
    // dependent list from the current value so the state field is selectable
    // immediately on returning to a form.
    if (countrySelect.value) loadRegions();
    else regionSelect.disabled = true;
  });
}

function getTeamAccent(team, index = 0) {
  const palette = [
    '#0f766e',
    '#2563eb',
    '#7c3aed',
    '#be123c',
    '#c2410c',
    '#047857',
    '#4338ca',
    '#b45309',
    '#0e7490',
    '#a21caf',
    '#15803d',
    '#1d4ed8'
  ];
  return palette[index % palette.length];
}

function getHomeTeamTitle(team) {
  if (team && (team.isNewTeam || !team.teamNumber)) return 'New Team';
  return team && team.teamNumber ? `#${team.teamNumber}` : 'Team';
}

function getHomeTeamYearsLabel(team) {
  const years = Number(team && team.yearsInProgram);
  if (team && (team.isNewTeam || !Number.isFinite(years) || years <= 0)) {
    return 'New Team Forming';
  }
  if (Number.isFinite(years)) {
    return `${years} year${years === 1 ? '' : 's'} in program`;
  }
  return 'Years not listed';
}

function getHomeTeamDescription(team) {
  const note = String(team && team.notes ? team.notes : '').trim();
  if (note) return note;
  if (team && team.isNewTeam) return 'A new team forming and looking for students nearby.';
  return 'View this recruiting team and see what they are looking for in students.';
}

function getHomeTeamBadgeLabel(team) {
  const rawName = String(team && team.name ? team.name : '').trim();
  if (rawName) {
    const words = rawName.split(/\s+/).filter(Boolean);
    const initials = words.slice(0, 2).map(word => word.charAt(0)).join('');
    if (initials) return initials;
  }
  if (team && team.program) {
    return String(team.program).trim().slice(0, 2);
  }
  if (team && team.teamNumber) {
    return String(team.teamNumber).slice(0, 2);
  }
  return 'FT';
}

function getTeamScoutingUrl(team) {
  if (!team || team.isNewTeam || !team.teamNumber) return null;
  const program = String(team.program || 'FTC').trim().toUpperCase();
  const teamNumber = encodeURIComponent(String(team.teamNumber));

  if (program === 'FTC') {
    return `https://ftcscout.org/teams/${teamNumber}`;
  }

  if (program === 'FRC') {
    return `https://www.thebluealliance.com/team/${teamNumber}`;
  }

  return null;
}

function renderHomeFeaturedTeams(teams) {
  const grid = document.getElementById('homeFeaturedTeams');
  if (!grid || !Array.isArray(teams) || !teams.length) return;

  const distanceUnitPreference = getDistanceUnitPreference();
  const orderedTeams = teams.slice().sort((left, right) => {
    const leftDistance = Number(left && left.distance);
    const rightDistance = Number(right && right.distance);
    const leftHasDistance = Number.isFinite(leftDistance);
    const rightHasDistance = Number.isFinite(rightDistance);
    if (!leftHasDistance && !rightHasDistance) return 0;
    if (!leftHasDistance) return 1;
    if (!rightHasDistance) return -1;
    return leftDistance - rightDistance;
  });

  grid.innerHTML = firstStartTrustedTypesPolicy.createHTML(orderedTeams.map((team, index) => {
    const accent = getTeamAccent(team, index);
    const location = [team.city, team.state, team.country].filter(Boolean).join(', ') || 'Location not listed';
    const distance = Number.isFinite(team.distance) ? formatDistance(team.distance, distanceUnitPreference).label : null;
    const numberLabel = getHomeTeamTitle(team);
    const yearsLabel = getHomeTeamYearsLabel(team);
    const isRecruiting = isTeamRecruiting(team);
    const statusLabel = isRecruiting ? 'Recruiting' : 'Not recruiting';
    const verifiedLabel = team.verified ? 'Verified' : 'Listed';
    const programLabel = team.program || 'FTC';
    const description = getHomeTeamDescription(team);
    const badgeLabel = getHomeTeamBadgeLabel(team);
    const barStyle = `background-color: ${accent};`;
    const numberStyle = `border-color: ${accent}33; background-color: ${accent}15; color: ${accent};`;
    const logoStyle = `border-color: ${accent}33; background-color: ${accent}12; color: ${accent};`;

    return `
      <article class="team-card" style="--team-accent: ${accent};">
        <div class="team-card-bar" style="${barStyle}"></div>
        <div class="team-card-body">
          <div class="team-card-top">
            <div class="team-card-brand">
              <div class="team-logo-badge" style="${logoStyle}">${escapeHTML(badgeLabel)}</div>
              <div class="team-number" style="${numberStyle}">${escapeHTML(numberLabel)}</div>
            </div>
            <span class="league-pill">${escapeHTML(programLabel)}</span>
          </div>
          <h3>${escapeHTML(team.name || 'Team')}</h3>
          <p class="team-location"><i class="fa-solid fa-map-pin" aria-hidden="true"></i> ${escapeHTML(location)}</p>
          <p class="team-description">${escapeHTML(description)}</p>
          <div class="team-meta">
            <span><span class="team-meta-icon" aria-hidden="true"><i class="fa-solid fa-location-crosshairs" aria-hidden="true"></i></span> ${escapeHTML(distance ? `${distance} away` : location)}</span>
            <span><span class="team-meta-icon" aria-hidden="true"><i class="fa-solid fa-calendar-days" aria-hidden="true"></i></span> ${escapeHTML(yearsLabel)}</span>
          </div>
          <div class="team-roles">
            <span>${escapeHTML(statusLabel)}</span>
            <span>${escapeHTML(verifiedLabel)}</span>
            <span>${escapeHTML(team.isNewTeam ? 'New Team' : 'Established')}</span>
          </div>
          <a href="/teams-nearby" class="team-button">View Team &amp; Apply</a>
        </div>
      </article>
    `;
  }).join(''));
}

function initHomeFeaturedTeams() {
  // Featured teams stay server-rendered. Users can search by city or ZIP;
  // precise browser location is never requested automatically.
}

// Signup page: toggle between seeker (join/make) and manager flows
function initSignupForm() {
  const form = document.getElementById('signupForm');
  if (!form) return;

  const modeButtons = document.querySelectorAll('.signup-mode');
  const modeInput = form.querySelector('#signupMode') || form.querySelector('input[name="signupMode"]');
  const managerContainer = form.querySelector('.signup-manager-fields');
  const seekerContainer = form.querySelector('.signup-seeker-fields');
  const currentUrl = new URL(window.location.href);
  currentUrl.hash = '';
  currentUrl.searchParams.delete('nocache');
  const currentPath = `${currentUrl.pathname}${currentUrl.search}`;
  const draftKey = `signup_draft:${currentPath}`;
  const returnKey = 'signup_terms_return_url';

  function captureDraft() {
    try {
      const payload = {};
      new FormData(form).forEach((value, key) => {
        payload[key] = value;
      });
      sessionStorage.setItem(draftKey, JSON.stringify(payload));
      sessionStorage.setItem(returnKey, currentPath);
    } catch (e) {}
  }

  function restoreDraft() {
    try {
      const raw = sessionStorage.getItem(draftKey);
      if (!raw) return;
      const payload = JSON.parse(raw);
      form.querySelectorAll('input, textarea, select').forEach((el) => {
        if (!el.name || !(el.name in payload)) return;
        if (el.type === 'checkbox' || el.type === 'radio') {
          const values = Array.isArray(payload[el.name]) ? payload[el.name].map(String) : [String(payload[el.name])];
          el.checked = values.includes(el.value);
        } else if (el.tagName === 'SELECT' || el.tagName === 'TEXTAREA') {
          el.value = String(payload[el.name]);
        } else if (el.type !== 'hidden') {
          el.value = String(payload[el.name]);
        }
      });
    } catch (e) {}
  }

  function setMode(mode) {
    modeButtons.forEach(btn => btn.classList.toggle('active', btn.dataset.mode === mode));
    if (modeInput) modeInput.value = mode;
    if (managerContainer) managerContainer.style.display = mode === 'manager' ? '' : 'none';
    if (seekerContainer) seekerContainer.style.display = mode === 'manager' ? 'none' : '';

    if (managerContainer) {
      managerContainer.querySelectorAll('input, textarea, select').forEach(el => el.disabled = mode !== 'manager');
    }
    if (seekerContainer) {
      seekerContainer.querySelectorAll('input, textarea, select').forEach(el => el.disabled = mode === 'manager');
    }

    try { sessionStorage.setItem('signup_intent', mode); } catch (e) {}
  }

  restoreDraft();
  form.querySelectorAll('input, textarea, select').forEach(el => {
    el.addEventListener('input', captureDraft);
    el.addEventListener('change', captureDraft);
  });

  const termsButton = form.querySelector('.terms-button');
  if (termsButton) {
    termsButton.setAttribute('href', '/terms#usercentrics-ppg');
    termsButton.addEventListener('click', captureDraft);
  }

  if (modeButtons && modeButtons.length > 0) {
    modeButtons.forEach(btn => btn.addEventListener('click', () => setMode(btn.dataset.mode)));
    // initialize default mode for combined page
    setMode('seeker');
  } else if (modeInput) {
    // standalone seeker/manager pages: respect server-provided hidden input or path
    const initial = modeInput.value || (window.location.pathname && window.location.pathname.includes('/signup/manager') ? 'manager' : 'seeker');
    // ensure containers/fields reflect the initial mode without overwriting server values
    if (managerContainer) managerContainer.style.display = initial === 'manager' ? '' : 'none';
    if (seekerContainer) seekerContainer.style.display = initial === 'manager' ? 'none' : '';
    if (managerContainer) managerContainer.querySelectorAll('input, textarea, select').forEach(el => el.disabled = initial !== 'manager');
    if (seekerContainer) seekerContainer.querySelectorAll('input, textarea, select').forEach(el => el.disabled = initial === 'manager');
    try { sessionStorage.setItem('signup_intent', initial); } catch (e) {}
  }
}

function initTermsPage() {
  const backLink = document.querySelector('[data-terms-back-link]');
  if (!backLink) return;

  try {
    const returnUrl = sessionStorage.getItem('signup_terms_return_url');
    if (returnUrl) backLink.setAttribute('href', returnUrl);
  } catch (e) {}
}

// Initialize on load
document.addEventListener('DOMContentLoaded', () => {
  initDeclarativeActions();
  initCharacterCounters();
  initPageAnimations();
  loadSharedFooter();
  loadSiteShells();
  initJoinForm();
  initAuthGatedActions();
  initHomeFeaturedTeams();
  initTeamsPage();
  initSignupForm();
  // Initialize this after signup draft/autofill restoration so a restored
  // country immediately hydrates its dependent state/region options.
  initCountryRegionSelects();
  initTermsPage();
});

function loadSharedFooter() {
  // Express injects the static footer before sending the page.
  const yearEl = document.getElementById('site-year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();
}

// Initialize the shared site shell injected by Express.
function loadSiteShells() {
  // Keep a local fallback for pages that are not rendered through Express.
  if (!document.body.classList.contains('home-page') && !document.querySelector('link[href*="bootstrap.min.css"]')) {
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = '/assets/vendor/bootstrap/bootstrap.min.css?v=3.3.6';
    const appStylesheet = document.querySelector('link[href*="/assets/css/main.css"], link[href*="assets/css/main.css"]');
    document.head.insertBefore(link, appStylesheet || document.head.firstChild);
  }

  const headerReady = Promise.resolve();

    headerReady.then(() => {

      // Immediately rewrite all links so they work even while auth is loading
      const initialAnchors = document.querySelectorAll('[data-href]');
      const gatedTargets = new Set(['/my-applications', '/team-register']);
      initialAnchors.forEach(a => {
        const target = a.getAttribute('data-href');
        if (!target) return;
        if (gatedTargets.has(target)) {
          const label = encodeURIComponent((a.textContent || '').trim());
          a.setAttribute('href', `/auth-gate?next=${encodeURIComponent(target)}${label ? `&label=${label}` : ''}`);
        } else {
          a.setAttribute('href', target);
        }
      });

      function bindNavbarDrawer() {
        const toggle = document.querySelector('[data-navbar-toggle]');
        const drawer = document.querySelector('[data-navbar-collapse]');
        if (!toggle || !drawer) return;

        const mobileQuery = window.matchMedia ? window.matchMedia('(max-width: 1280px)') : null;

        function syncDrawerState() {
          const isMobile = mobileQuery ? mobileQuery.matches : window.innerWidth <= 1120;
          const isOpen = drawer.classList.contains('is-open');

          if (!isMobile) {
            drawer.hidden = false;
            drawer.classList.remove('is-open');
            toggle.setAttribute('aria-expanded', 'false');
            return;
          }

          drawer.hidden = !isOpen;
          toggle.setAttribute('aria-expanded', String(isOpen));
        }

        if (!toggle.dataset.bound) {
          toggle.dataset.bound = 'true';
          toggle.addEventListener('click', (event) => {
            event.preventDefault();
            event.stopPropagation();
            const isOpen = drawer.classList.contains('is-open');
            drawer.classList.toggle('is-open', !isOpen);
            drawer.hidden = isOpen;
            toggle.setAttribute('aria-expanded', String(!isOpen));
          });
        }

        if (!window.__navbarDrawerListenerBound) {
          window.__navbarDrawerListenerBound = true;
          document.addEventListener('click', (event) => {
            if (!drawer.classList.contains('is-open')) return;
            if (drawer.contains(event.target) || toggle.contains(event.target)) return;
            drawer.classList.remove('is-open');
            drawer.hidden = true;
            toggle.setAttribute('aria-expanded', 'false');
          });
        }

        if (mobileQuery && !toggle.dataset.breakpointBound) {
          toggle.dataset.breakpointBound = 'true';
          mobileQuery.addEventListener('change', syncDrawerState);
        }

        window.addEventListener('resize', syncDrawerState, { passive: true });
        syncDrawerState();
        window.requestAnimationFrame(syncDrawerState);
        window.setTimeout(syncDrawerState, 0);
      }

      bindNavbarDrawer();

      // Anonymous pages can initialize immediately without an extra API request.
      const authRequest = document.documentElement.dataset.authState === 'anonymous'
        ? Promise.resolve({ user: null, notifications: [], unreadCount: 0 })
        : fetch('/api/users/me').then(r => r.json());

      // Update links and toggle visibility based on auth status.
      authRequest
        .then(data => { 
          const user = data.user;
          window.__USER__ = user || null;
          const anchors = document.querySelectorAll('[data-href]');
          const navUserControls = document.querySelector('.nav-user-controls');
          const inboxMenu = document.querySelector('.inbox-menu');
          const inboxToggle = document.querySelector('[data-inbox-toggle]');
          const inboxDropdown = document.querySelector('[data-inbox-dropdown]');
          const inboxList = document.querySelector('[data-inbox-list]');
          const inboxEmpty = document.querySelector('[data-inbox-empty]');
          const inboxTitle = document.querySelector('[data-inbox-title]');
          const inboxClear = document.querySelector('[data-inbox-clear]');
          const accountMenu = document.querySelector('.account-menu');
          const accountToggle = document.querySelector('[data-account-toggle]');
          const accountDropdown = document.querySelector('[data-account-dropdown]');
          const initialsEl = document.querySelector('[data-account-initials]');
          const accountLabelEl = document.querySelector('.account-label');
          const inboxCountEls = document.querySelectorAll('[data-inbox-count]');
          const statsLink = accountDropdown ? accountDropdown.querySelector('a[data-href="/stats"]') : null;
          const reportsLink = accountDropdown ? accountDropdown.querySelector('a[data-href="/reports"]') : null;
          const settingsLink = accountDropdown ? accountDropdown.querySelector('a[data-href="/account"]') : null;
          const signOutLink = accountDropdown ? accountDropdown.querySelector('a[data-href="/logout"]') : null;
          let notifications = Array.isArray(data.notifications) ? data.notifications : [];
          let unreadCount = Number.isFinite(Number(data.unreadCount)) ? Number(data.unreadCount) : 0;
          const canViewTeamEmailDirectory = Boolean(user && (
            user.canViewTeamEmailDirectory
            || String(user.email || '').trim().toLowerCase() === 'evergreentechatrons.contact@gmail.com'
          ));

          function formatNotificationDate(value) {
            const date = value ? new Date(value) : null;
            if (!date || Number.isNaN(date.getTime())) return '';
            return date.toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
          }

          function syncUnreadCount(nextCount) {
            unreadCount = Math.max(0, Number(nextCount) || 0);
            inboxCountEls.forEach((el) => {
              el.textContent = el.classList.contains('inbox-dropdown-count')
                ? (unreadCount > 0 ? `${unreadCount} new` : 'All caught up')
                : String(unreadCount);
            });
          }

          function updateInboxControls() {
            if (!inboxClear) return;
            const hasNotifications = notifications.length > 0;
            inboxClear.disabled = !hasNotifications;
            inboxClear.classList.toggle('is-disabled', !hasNotifications);
          }

          function renderNotifications() {
            if (!inboxList || !inboxEmpty || !inboxTitle) return;

            if (!notifications.length) {
              inboxList.replaceChildren();
              inboxEmpty.hidden = false;
              inboxTitle.textContent = 'Inbox';
              updateInboxControls();
              return;
            }

            inboxEmpty.hidden = true;
            inboxTitle.textContent = unreadCount > 0 ? 'New notifications' : 'Notifications';
            const notificationElements = notifications.map((notification) => {
              const rawLink = typeof notification.link === 'string' ? notification.link.trim() : '';
              const link = rawLink.startsWith('/') && !rawLink.startsWith('//') ? rawLink : '/account';
              const meta = formatNotificationDate(notification.createdAt);
              const item = document.createElement('a');
              item.className = `inbox-dropdown-item${notification.readAt ? ' is-read' : ''}`;
              item.href = link;
              item.dataset.notificationLink = '';
              const title = document.createElement('strong');
              title.textContent = String(notification.title || 'Notification');
              const body = document.createElement('span');
              body.textContent = String(notification.body || '');
              item.append(title, body);
              if (meta) {
                const date = document.createElement('span');
                date.className = 'inbox-dropdown-item-meta';
                date.textContent = meta;
                item.appendChild(date);
              }
              return item;
            });
            inboxList.replaceChildren(...notificationElements);
            updateInboxControls();
          }

          renderNotifications();
          syncUnreadCount(unreadCount);

          if (navUserControls) navUserControls.style.display = user ? 'inline-flex' : 'none';
          if (inboxToggle) inboxToggle.setAttribute('aria-expanded', 'false');
          if (inboxDropdown) inboxDropdown.hidden = true;
          if (accountToggle) accountToggle.setAttribute('aria-expanded', 'false');
          if (accountDropdown) accountDropdown.hidden = true;
          if (initialsEl && user) {
            const initials = user.name
              ? user.name
                .split(/\s+/)
                .filter(Boolean)
                .slice(0, 2)
                .map(part => part[0].toUpperCase())
                .join('') || 'U'
              : 'U';
            if (user.profilePicture) {
              const profileImage = document.createElement('img');
              profileImage.src = String(user.profilePicture);
              profileImage.alt = 'Profile picture';
              initialsEl.replaceChildren(profileImage);
            } else {
              initialsEl.textContent = initials;
            }
          } else if (initialsEl) {
            initialsEl.textContent = 'U';
          }

          if (user) {
            if (accountLabelEl) accountLabelEl.textContent = 'Account';
            renderNotifications();
            syncUnreadCount(unreadCount);
            if (settingsLink) {
              settingsLink.setAttribute('href', '/account');
              settingsLink.setAttribute('data-href', '/account');
              settingsLink.textContent = 'Settings';
            }
            if (signOutLink) {
              signOutLink.setAttribute('href', '/logout');
              signOutLink.setAttribute('data-href', '/logout');
              signOutLink.textContent = 'Sign Out';
            }
            if (statsLink) {
              const canViewStats = Boolean(user.canViewStats);
              statsLink.style.display = canViewStats ? '' : 'none';
              if (canViewStats) {
                statsLink.setAttribute('href', '/stats');
                statsLink.setAttribute('data-href', '/stats');
              }
            }
            if (reportsLink) {
              const canViewReports = Boolean(user.canViewReports || ['evergreentechatrons.contact@gmail.com', 'evergreentechatrons@gmail.com'].includes(String(user.email || '').trim().toLowerCase()));
              reportsLink.style.display = canViewReports ? '' : 'none';
              if (canViewReports) {
                reportsLink.setAttribute('href', '/reports');
                reportsLink.setAttribute('data-href', '/reports');
              }
            }
          }

          if (inboxClear && !inboxClear.dataset.bound) {
            inboxClear.dataset.bound = 'true';
            inboxClear.addEventListener('click', async (event) => {
              event.preventDefault();
              event.stopPropagation();
              if (!user || !notifications.length) return;

              try {
                await fetch('/api/notifications/clear', { method: 'POST' });
              } catch (e) {}

              notifications = [];
              unreadCount = 0;
              renderNotifications();
              syncUnreadCount(0);
            });
          }

          if (inboxToggle && !inboxToggle.dataset.bound) {
            inboxToggle.dataset.bound = 'true';
            inboxToggle.addEventListener('click', async (event) => {
              event.preventDefault();
              event.stopPropagation();
              const menu = inboxToggle.closest('.inbox-menu');
              const dropdown = menu && menu.querySelector('[data-inbox-dropdown]');
              const expanded = inboxToggle.getAttribute('aria-expanded') === 'true';
              if (dropdown) dropdown.hidden = expanded;
              inboxToggle.setAttribute('aria-expanded', String(!expanded));
              if (menu) menu.classList.toggle('is-open', !expanded);

              if (!expanded && user && unreadCount > 0) {
                try {
                  await fetch('/api/notifications/read', { method: 'POST' });
                } catch (e) {}
                notifications = notifications.map(notification => notification.readAt ? notification : { ...notification, readAt: new Date().toISOString() });
                renderNotifications();
                syncUnreadCount(0);
              }

              const accountMenuEl = document.querySelector('.account-menu');
              if (accountMenuEl) {
                accountMenuEl.classList.remove('is-open');
                const accountToggleEl = accountMenuEl.querySelector('[data-account-toggle]');
                const accountDropdownEl = accountMenuEl.querySelector('[data-account-dropdown]');
                if (accountToggleEl) accountToggleEl.setAttribute('aria-expanded', 'false');
                if (accountDropdownEl) accountDropdownEl.hidden = true;
              }
            });
          }

          if (accountToggle && !accountToggle.dataset.bound) {
            accountToggle.dataset.bound = 'true';
            accountToggle.addEventListener('click', (event) => {
              event.preventDefault();
              event.stopPropagation();
              const menu = accountToggle.closest('.account-menu');
              const dropdown = menu && menu.querySelector('[data-account-dropdown]');
              const expanded = accountToggle.getAttribute('aria-expanded') === 'true';
              if (dropdown) dropdown.hidden = expanded;
              accountToggle.setAttribute('aria-expanded', String(!expanded));
              if (menu) menu.classList.toggle('is-open', !expanded);

              const inboxMenuEl = document.querySelector('.inbox-menu');
              if (inboxMenuEl) {
                inboxMenuEl.classList.remove('is-open');
                const inboxToggleEl = inboxMenuEl.querySelector('[data-inbox-toggle]');
                const inboxDropdownEl = inboxMenuEl.querySelector('[data-inbox-dropdown]');
                if (inboxToggleEl) inboxToggleEl.setAttribute('aria-expanded', 'false');
                if (inboxDropdownEl) inboxDropdownEl.hidden = true;
              }
            });
          }

          if (!window.__navMenusListenerBound) {
            window.__navMenusListenerBound = true;
            document.addEventListener('click', (event) => {
              ['.inbox-menu', '.account-menu'].forEach(selector => {
                const menu = document.querySelector(selector);
                if (!menu || !menu.classList.contains('is-open')) return;
                if (menu.contains(event.target)) return;
                menu.classList.remove('is-open');
                const toggle = menu.querySelector('button[aria-haspopup="true"]');
                const dropdown = menu.querySelector('[data-inbox-dropdown], [data-account-dropdown]');
                if (toggle) toggle.setAttribute('aria-expanded', 'false');
                if (dropdown) dropdown.hidden = true;
              });
            });
          }

          anchors.forEach(a => {
            // Toggle visibility based on auth status
            const target = a.getAttribute('data-href');
            const navItem = a.closest('li') || a;
            const intent = (() => { try { return sessionStorage.getItem('signup_intent'); } catch (e) { return null; }})();
            if (target === '/login' || target === '/signup') {
              navItem.style.display = user ? 'none' : '';
              if (user) a.setAttribute('href', target);
            } else if (target === '/team-register') {
              navItem.style.display = '';
              if (user) {
                a.setAttribute('href', target);
              } else {
                const label = encodeURIComponent((a.textContent || '').trim());
                a.setAttribute('href', `/auth-gate?next=${encodeURIComponent(target)}${label ? `&label=${label}` : ''}`);
              }
            } else if (target === '/manage-team') {
              navItem.style.display = (user && user.hasTeam) ? '' : 'none';
              if (user) a.setAttribute('href', target);
            } else if (target === '/stats') {
              const canViewStats = Boolean(user && user.canViewStats);
              navItem.style.display = canViewStats ? '' : 'none';
              if (canViewStats) a.setAttribute('href', target);
            } else if (target === '/reports') {
              const canViewReports = Boolean(user && (user.canViewReports || ['evergreentechatrons.contact@gmail.com', 'evergreentechatrons@gmail.com'].includes(String(user.email || '').trim().toLowerCase())));
              navItem.style.display = canViewReports ? '' : 'none';
              if (canViewReports) a.setAttribute('href', target);
            } else if (target === '/team-email-directory') {
              navItem.hidden = !canViewTeamEmailDirectory;
              navItem.style.display = canViewTeamEmailDirectory ? '' : 'none';
              if (canViewTeamEmailDirectory) a.setAttribute('href', target);
            } else if (target === '/my-applications' || target === '/join-form') {
              // Show applications/join form only for students.
              // If the user is focused on registering a team, keep the header focused on that path instead.
              navItem.style.display = (user && !user.hasTeam && intent !== 'manager') ? '' : 'none';
              a.setAttribute('href', target);
            } else if (target === '/my-team') {
              navItem.style.display = (user && user.hasTeam) ? '' : 'none';
              if (user) a.setAttribute('href', target);
            }
          });
        }).catch(() => {});

      }).catch(() => {});

    // (removed) prefix calculation — always use absolute paths for partials
}
