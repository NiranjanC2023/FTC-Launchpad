// Dark mode removed: ensure no `data-theme` attribute remains
document.documentElement.removeAttribute('data-theme');

const firstStartTrustedTypesPolicy = window.trustedTypes
  ? window.trustedTypes.createPolicy('first-start', { createHTML: (value) => value })
  : { createHTML: (value) => value };

function escapeHTML(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  }[char]));
}

// Persist signup intent early so header logic can read it on load
(function setSignupIntentFromPath() {
  try {
    const p = (window.location && window.location.pathname) || '/';
    if (p.startsWith('/signup/manager')) {
      sessionStorage.setItem('signup_intent', 'manager');
    } else if (p.startsWith('/signup/seeker')) {
      sessionStorage.setItem('signup_intent', 'seeker');
    } else if (p === '/signup') {
      // selection page — clear any previous intent so navbar stays minimal
      sessionStorage.removeItem('signup_intent');
    }
  } catch (e) { /* ignore storage errors */ }
})();

// Copy code functionality
function copyCode(button) {
  const codeBlock = button.closest('.code-block');
  const code = codeBlock.querySelector('code').textContent;
  
  navigator.clipboard.writeText(code).then(() => {
    const originalText = button.textContent;
    button.textContent = 'Copied!';
    setTimeout(() => {
      button.textContent = originalText;
    }, 2000);
  }).catch(err => {
    console.error('Failed to copy code:', err);
  });
}

function getCurrentUser() {
  return window.__USER__ || window.__CURRENT_USER__ || null;
}

function redirectToAuthGate(nextPath, label) {
  const safeNext = nextPath || window.location.pathname || '/';
  const safeLabel = label ? `&label=${encodeURIComponent(label)}` : '';
  window.location.href = `/auth-gate?next=${encodeURIComponent(safeNext)}${safeLabel}`;
}

function requireAuthForAction(nextPath, label, event) {
  if (getCurrentUser()) return true;
  if (event) {
    event.preventDefault();
    event.stopPropagation();
  }
  redirectToAuthGate(nextPath, label);
  return false;
}

function initPageAnimations() {
  try {
    if (!document.body) return;
    const reducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reducedMotion) {
      document.body.classList.remove('page-motion-ready');
      return;
    }

    document.body.classList.add('page-motion-ready');

    const selectors = [
      'main > .container',
      'main > section',
      'main > article',
      'main > .row',
      '.dashboard-panel',
      '.page-header',
      '.card',
      '.hero',
      '.feature-card',
      '.path-card',
      '.step-card',
      '.team-card',
      '.recruit-card',
      '.resource-card',
      '.info-card',
      '.panel',
      '.stats-grid > *',
      '.team-history-item',
      '.team-compare-card',
      '.teams-list > *',
      '.account-section',
      '.form-grid',
      '.auth-card'
    ];

    const targets = Array.from(document.querySelectorAll(selectors.join(',')));
    if (!targets.length) return;

    const seen = new WeakSet();
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -4% 0px' });

    targets.forEach((target, index) => {
      if (seen.has(target)) return;
      seen.add(target);
      target.classList.add('reveal-on-scroll');
      target.style.transitionDelay = `${Math.min(index, 14) * 35}ms`;
      observer.observe(target);
    });
  } catch (err) {
    // Animation is decorative only; never block page behavior if it fails.
  }
}

// ---------- Join form + Teams pages logic ----------

const STUDENT_KEY = 'studentInfo_v1';

// Remove applicant PII copied into browser storage by older releases.
try {
  sessionStorage.removeItem(STUDENT_KEY);
  localStorage.removeItem(STUDENT_KEY);
} catch (e) {}

function initJoinForm() {
  const form = document.getElementById('joinForm');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/signups', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
      });
      const payload = await response.json().catch(() => ({}));
      if (response.status === 401) {
        redirectToAuthGate('/join-form', 'Join a Team');
        return;
      }
      if (!response.ok) {
        alert(payload.error || 'Unable to save your profile right now.');
        return;
      }
      window.location.href = '/teams-nearby';
    } catch (err) {
      console.error('Failed to save to database:', err);
      alert('Unable to save your profile right now.');
    }
  });
}

function initAuthGatedActions() {
  const startTeamCards = document.querySelectorAll('.roadmap-card');
  startTeamCards.forEach((card) => {
    if (card.dataset.authBound) return;
    card.dataset.authBound = 'true';
    card.addEventListener('click', (event) => {
      const target = card.getAttribute('href') || '/start-team';
      const label = (card.querySelector('strong') || card.querySelector('h3') || card).textContent.trim();
      requireAuthForAction(target, label, event);
    });
  });

  const resourceLinks = document.querySelectorAll('.resource-links a');
  const publicResourcePaths = new Set([
    '/sdk',
    '/programming',
    '/advanced-programming',
    '/controller-setup',
    '/drivetrain',
    '/mechanical-parts',
    '/assembly',
    '/motor-selection',
    '/funding',
    '/sponsorship',
    '/outreach',
    '/team-org'
  ]);
  resourceLinks.forEach((link) => {
    if (link.dataset.authBound) return;
    if (link.dataset.publicResource === 'true' || link.origin !== window.location.origin) return;
    if (link.pathname.startsWith('/resources/') || publicResourcePaths.has(link.pathname)) return;
    link.dataset.authBound = 'true';
    link.addEventListener('click', (event) => {
      requireAuthForAction(link.getAttribute('href') || '/resources', (link.textContent || '').trim(), event);
    });
  });
}

function isTeamRecruiting(team) {
  const value = team && typeof team === 'object' ? team.recruiting : undefined;
  if (value === false || value === 0) return false;

  const normalized = String(value ?? '').trim().toLowerCase();
  if (!normalized) return true;
  if (['false', '0', 'off', 'no', 'n', 'inactive', 'not recruiting'].includes(normalized)) {
    return false;
  }

  return true;
}

function normalizeCountryName(value) {
  const normalized = String(value || '')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim()
    .replace(/\s+/g, ' ');
  const aliases = {
    us: 'united states',
    'u s': 'united states',
    usa: 'united states',
    'u s a': 'united states',
    'united states of america': 'united states',
    uk: 'united kingdom',
    'u k': 'united kingdom',
    gb: 'united kingdom',
    'great britain': 'united kingdom',
    uae: 'united arab emirates',
    'u a e': 'united arab emirates'
  };
  return aliases[normalized] || normalized;
}

function getCountryApplicationState(team) {
  const user = getCurrentUser();
  if (!user) return { needsCountry: false, outsideCountry: false };
  const userCountry = normalizeCountryName(user.country);
  const teamCountry = normalizeCountryName(team && team.country);
  return {
    needsCountry: !userCountry,
    outsideCountry: Boolean(userCountry && (!teamCountry || userCountry !== teamCountry))
  };
}

function initDeclarativeActions() {
  document.querySelectorAll('[data-copy-code]').forEach((button) => {
    button.addEventListener('click', () => copyCode(button));
  });
  document.querySelectorAll('[data-auto-submit]').forEach((field) => {
    field.addEventListener('change', () => {
      if (field.form) field.form.requestSubmit();
    });
  });
}

// A small list of sample teams retained for legacy integrations.
const SAMPLE_TEAMS = [
  { name: 'Rookie Robotics', lat: 40.7128, lon: -74.0060, contact: 'rookierobotics@example.com' },
  { name: 'Northside FTC', lat: 40.730610, lon: -73.935242, contact: 'northsideftc@example.com' },
  { name: 'Riverdale Robotics', lat: 40.6782, lon: -73.9442, contact: 'riverdalerobotics@example.com' }
];

function haversineDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // km
  const toRad = (v) => v * Math.PI / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

function getDistanceUnitPreference() {
  const locale = String(
    navigator.language ||
    Intl.DateTimeFormat().resolvedOptions().locale ||
    ''
  );
  const regionMatch = locale.match(/[-_](?<region>[A-Z]{2}|\d{3})$/);
  const region = regionMatch && regionMatch.groups ? regionMatch.groups.region : '';
  return new Set(['US', 'LR', 'MM', 'GB']).has(region) ? 'imperial' : 'metric';
}

function formatDistance(distanceKm, unitPreference) {
  const useImperial = unitPreference === 'imperial';
  const value = useImperial ? distanceKm * 0.621371 : distanceKm;
  const unit = useImperial ? 'mi' : 'km';
  return {
    value,
    label: `${value.toFixed(value < 10 ? 1 : 0)} ${unit}`
  };
}

function formatAwardHistoryDisplayEntry(entry) {
  const value = String(entry || '').trim();
  if (!value) return '';
  return value.replace(/^\s*(Winner|Finalist)\b/i, (_, word) => (
    word.toLowerCase() === 'winner' ? 'Winning Alliance' : 'Finalist Alliance'
  ));
}

function distanceThresholdToKm(value, unitPreference) {
  if (!Number.isFinite(value)) return null;
  return unitPreference === 'imperial' ? value / 0.621371 : value;
}

function createUserLocationMarker(map, userCoords, bounds) {
  if (!map || !userCoords || typeof userCoords.lat !== 'number' || typeof userCoords.lon !== 'number') return null;

  const marker = L.marker([userCoords.lat, userCoords.lon], {
    interactive: false,
    keyboard: false,
    title: 'Your location',
    icon: L.divIcon({
      className: 'user-location-marker-icon',
      html: `
        <div class="user-location-marker-wrap" aria-hidden="true">
          <span class="user-location-marker-tag">Your location</span>
          <span class="team-zoom-notifier team-zoom-notifier--user"></span>
        </div>
      `,
      iconSize: [88, 46],
      iconAnchor: [44, 40],
      popupAnchor: [0, -28]
    })
  }).addTo(map);

  if (bounds) {
    bounds.extend([userCoords.lat, userCoords.lon]);
  }

  return marker;
}

function renderTeams(teams, userCoords) {
  const list = document.getElementById('teamsList');
  if (!list) return;

  const hasUserCoords = userCoords
    && Number.isFinite(Number(userCoords.lat))
    && Number.isFinite(Number(userCoords.lon));
  const orderedTeams = hasUserCoords
    ? teams.slice().sort((left, right) => {
      const leftDistance = haversineDistance(userCoords.lat, userCoords.lon, Number(left.lat), Number(left.lon));
      const rightDistance = haversineDistance(userCoords.lat, userCoords.lon, Number(right.lat), Number(right.lon));
      if (!Number.isFinite(leftDistance)) return 1;
      if (!Number.isFinite(rightDistance)) return -1;
      return leftDistance - rightDistance;
    })
    : teams;

  // clear list
  list.replaceChildren();
  window._teamMarkers = {};
  window._userLocationMarker = null;
  window._infoWindowTimer = null;
  window._infoWindow = null; // Reset infoWindow to ensure it's recreated with new map instance
  window._teamCards = {};

  // ensure a map container exists above the list
  let mapEl = document.getElementById('teamsMap');
  if (!mapEl) {
    mapEl = document.createElement('div');
    mapEl.id = 'teamsMap';
    mapEl.style.width = '100%';
    mapEl.style.height = '400px';
    list.parentNode.insertBefore(mapEl, list);
  }

  // create a simple accessible list alongside the map
  const programOptions = ['All', 'FTC', 'FRC', 'FLL Challenge'];
  const distanceUnitPreference = getDistanceUnitPreference();
  const distanceFilterOptions = distanceUnitPreference === 'imperial'
    ? [
        { value: 'all', label: 'Any distance' },
        { value: '5', label: 'Within 5 mi' },
        { value: '10', label: 'Within 10 mi' },
        { value: '25', label: 'Within 25 mi' },
        { value: '50', label: 'Within 50 mi' }
      ]
    : [
        { value: 'all', label: 'Any distance' },
        { value: '5', label: 'Within 5 km' },
        { value: '10', label: 'Within 10 km' },
        { value: '25', label: 'Within 25 km' },
        { value: '50', label: 'Within 50 km' }
      ];
  const searchWrap = document.createElement('div');
  searchWrap.className = 'teams-search';
  searchWrap.innerHTML = firstStartTrustedTypesPolicy.createHTML(`
    <label for="teamsSearch">Search teams</label>
    <div class="teams-search-row">
      <div class="teams-search-field">
        <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
        <input id="teamsSearch" type="search" placeholder="Search by team or location" autocomplete="off" />
        <div class="teams-filter-menu">
          <button type="button" class="teams-filter-button" aria-haspopup="true" aria-expanded="false" aria-controls="teamsProgramDropdown">
            <i class="fa-solid fa-filter" aria-hidden="true"></i>
            <span>Filters</span>
          </button>
          <div id="teamsProgramDropdown" class="teams-filter-dropdown" hidden>
            <label for="teamsProgramFilter">FIRST program</label>
            <select id="teamsProgramFilter" class="teams-program-filter" aria-label="Filter teams by FIRST program">
              ${programOptions.map(program => `<option value="${escapeHTML(program)}">${program === 'All' ? 'All programs' : escapeHTML(program)}</option>`).join('')}
            </select>
            <label for="teamsAwardsFilter">Awards</label>
            <select id="teamsAwardsFilter" class="teams-program-filter" aria-label="Filter teams by awards">
              <option value="all">All teams</option>
              <option value="has-awards">Has awards listed</option>
              <option value="no-awards">No awards listed</option>
            </select>
            <label for="teamsYearsFilter">Years in program</label>
            <select id="teamsYearsFilter" class="teams-program-filter" aria-label="Filter teams by years in program">
              <option value="all">All years</option>
              <option value="new-team">New teams</option>
              <option value="rookie">Rookie (1-2 years)</option>
              <option value="mid">3-5 years</option>
              <option value="veteran">6+ years</option>
              <option value="unknown">Unknown</option>
            </select>
            <label for="teamsAdvancementFilter">Advancement</label>
            <select id="teamsAdvancementFilter" class="teams-program-filter" aria-label="Filter teams by advancement level">
              <option value="all">All advancement</option>
              <option value="Qualifier">Qualifiers</option>
              <option value="Regional">Regionals</option>
              <option value="Worlds">Worlds</option>
              <option value="unknown">Unknown</option>
            </select>
            <label for="teamsDistanceFilter">Distance</label>
            <select id="teamsDistanceFilter" class="teams-program-filter" aria-label="Filter teams by distance">
              ${distanceFilterOptions.map(option => `<option value="${option.value}">${escapeHTML(option.label)}</option>`).join('')}
            </select>
            <div class="teams-filter-actions">
              <button type="button" class="teams-filter-clear">Clear filters</button>
            </div>
          </div>
        </div>
      </div>
      <span class="teams-search-count" aria-live="polite"></span>
    </div>
  `);

  const teamsListContainer = document.createElement('div');
  teamsListContainer.className = 'teams-list-container';

  teamsListContainer.appendChild(searchWrap);

  const emptyEl = document.createElement('p');
  emptyEl.className = 'teams-empty';
  emptyEl.hidden = true;
  emptyEl.textContent = 'No teams match your search.';
  teamsListContainer.appendChild(emptyEl);

  const listEl = document.createElement('div');
  listEl.className = 'teams-list-cards';
  teamsListContainer.appendChild(listEl);

  list.appendChild(teamsListContainer);

  const searchInput = searchWrap.querySelector('#teamsSearch');
  const programFilter = searchWrap.querySelector('#teamsProgramFilter');
  const awardsFilter = searchWrap.querySelector('#teamsAwardsFilter');
  const yearsFilter = searchWrap.querySelector('#teamsYearsFilter');
  const advancementFilter = searchWrap.querySelector('#teamsAdvancementFilter');
  const distanceFilter = searchWrap.querySelector('#teamsDistanceFilter');
  const filterMenu = searchWrap.querySelector('.teams-filter-menu');
  const filterButton = searchWrap.querySelector('.teams-filter-button');
  const filterDropdown = searchWrap.querySelector('.teams-filter-dropdown');
  const clearFiltersButton = searchWrap.querySelector('.teams-filter-clear');
  const resultCount = searchWrap.querySelector('.teams-search-count');

  function escapeHTML(value) {
    return String(value ?? '').replace(/[&<>"']/g, char => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;'
    }[char]));
  }

function normalizeAdvancementLevel(level) {
  const value = String(level ?? '').trim().toLowerCase();
  if (!value) return '';
  if (value.includes('scrimmag')) return '';
    if (value.startsWith('qual') || value.includes('super qualifier') || value.includes('league tournament') || value.includes('league meet')) return 'Qualifier';
    if (value.startsWith('reg') || value.includes('premier')) return 'Regional';
    if (value.startsWith('world') || value.includes('first championship') || value.includes('firstchampionship') || value.includes('world championship')) return 'Worlds';
    if (value.includes('championship')) return 'Regional';
  return level;
}

function getTeamRecruitingLabel(team) {
  return isTeamRecruiting(team) ? 'Recruiting' : 'Not recruiting';
}

  function advancementLevelRank(level) {
    const normalized = normalizeAdvancementLevel(level);
    if (normalized === 'Worlds') return 3;
    if (normalized === 'Regional') return 2;
    if (normalized === 'Qualifier') return 1;
    return 0;
  }

  function sortAdvancementLevels(levels) {
    return Array.isArray(levels)
      ? Array.from(new Set(levels.map(normalizeAdvancementLevel).filter(Boolean)))
        .sort((left, right) => {
          const diff = advancementLevelRank(right) - advancementLevelRank(left);
          if (diff) return diff;
          return String(left).localeCompare(String(right));
        })
      : [];
  }

  function formatAdvancementEntry(entry, levels, index) {
    const value = String(entry ?? '').trim();
    if (!value) return '';
    if (/^(Qualifier|Regional|Worlds|Super Qualifier|League Tournament|League Meet|Premier|Championship)\b/i.test(value) && /\d{4}/.test(value)) {
      return value.replace(/\s*-\s*/g, ' - ');
    }
    if (/^(Qualifier|Regional|Worlds|Super Qualifier|League Tournament|League Meet|Premier|Championship)\b/i.test(value)) return value;
    if (/^(?:19|20)\d{2}$/.test(value)) {
      const orderedLevels = sortAdvancementLevels(levels);
      const level = orderedLevels.length ? orderedLevels[index % orderedLevels.length] : '';
      return level ? `${level} - ${value}` : value;
    }
    return value;
  }

  function getAdvancementIconClass(entry) {
    const value = normalizeAdvancementLevel(entry);
    if (value === 'Qualifier') return 'fa-solid fa-flag';
    if (value === 'Regional') return 'fa-solid fa-map-location-dot';
    if (value === 'Worlds') return 'fa-solid fa-globe';
    return 'fa-solid fa-flag-checkered';
  }

  function getAdvancementToneClass(entry) {
    const value = normalizeAdvancementLevel(entry);
    if (value === 'Qualifier') return 'qualifier';
    if (value === 'Regional') return 'regional';
    if (value === 'Worlds') return 'worlds';
    return 'other';
  }

  function activateMarkerLabel(teamName) {
    document.querySelectorAll('.marker-label').forEach(el => {
      el.classList.add('marker-label--dim');
      el.classList.remove('marker-label--active');
    });
    // Circle focus is handled through the matching card and map popup.
  }

  function applySearch() {
    const query = searchInput.value.trim().toLowerCase();
    const selectedProgram = programFilter ? programFilter.value : 'All';
    const selectedAwards = awardsFilter ? awardsFilter.value : 'all';
    const selectedYears = yearsFilter ? yearsFilter.value : 'all';
    const selectedAdvancement = advancementFilter ? advancementFilter.value : 'all';
    const selectedDistance = distanceFilter ? distanceFilter.value : 'all';
    const normalizedSelectedAdvancement = normalizeAdvancementLevel(selectedAdvancement);
    let visibleCount = 0;

    Object.values(window._teamCards).forEach(card => {
      const matchesProgram = selectedProgram === 'All' || card.dataset.program === selectedProgram;
      const hasAwards = card.dataset.hasAwards === 'true';
      const yearsInProgram = Number(card.dataset.yearsInProgram || '');
      const advancementLevels = String(card.dataset.advancementLevels || '')
        .split('|')
        .map(normalizeAdvancementLevel)
        .filter(Boolean);
      const distanceKm = card.dataset.distanceKm ? Number(card.dataset.distanceKm) : NaN;
      const matchesAwards = selectedAwards === 'all'
        || (selectedAwards === 'has-awards' && hasAwards)
        || (selectedAwards === 'no-awards' && !hasAwards);
      const matchesYears = selectedYears === 'all'
        || (selectedYears === 'new-team' && card.dataset.isNewTeam === 'true')
        || (selectedYears === 'unknown' && !Number.isFinite(yearsInProgram))
        || (selectedYears === 'rookie' && Number.isFinite(yearsInProgram) && yearsInProgram >= 1 && yearsInProgram <= 2)
        || (selectedYears === 'mid' && Number.isFinite(yearsInProgram) && yearsInProgram >= 3 && yearsInProgram <= 5)
        || (selectedYears === 'veteran' && Number.isFinite(yearsInProgram) && yearsInProgram >= 6);
      const matchesAdvancement = selectedAdvancement === 'all'
        || (selectedAdvancement === 'unknown' && advancementLevels.length === 0)
        || advancementLevels.includes(normalizedSelectedAdvancement);
      const maxDistanceKm = distanceThresholdToKm(Number(selectedDistance), distanceUnitPreference);
      const matchesDistance = selectedDistance === 'all'
        || (Number.isFinite(distanceKm) && Number.isFinite(maxDistanceKm) && distanceKm <= maxDistanceKm);
      const matches = matchesProgram && matchesAwards && matchesYears && matchesAdvancement && matchesDistance && (!query || card.dataset.search.includes(query));
      card.hidden = !matches;
      if (matches) visibleCount++;

      setTeamLayerVisible(card.dataset.team, matches);
    });

    resultCount.textContent = `${visibleCount} team${visibleCount === 1 ? '' : 's'}`;
    emptyEl.hidden = visibleCount !== 0;
  }

  function highlightTeamCard(teamName, options = {}) {
    const card = window._teamCards[teamName];
    if (!card) return;

    if (card.hidden) {
      searchInput.value = '';
      applySearch();
    }

    Object.values(window._teamCards).forEach(item => item.classList.remove('is-active'));
    card.classList.add('is-active');

    if (options.scroll) {
      card.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }

  function focusTeam(teamName, options = {}) {
    const marker = (window._teamMarkers || {})[teamName];
    const map = window._teamsMapInstance;

    highlightTeamCard(teamName, { scroll: Boolean(options.scroll) });
    activateMarkerLabel(teamName);

    if (!marker || !map) return false;

    try {
      if (marker.getLatLng && map.setView) {
        map.setView(marker.getLatLng(), Math.max(map.getZoom(), options.zoom || 12));
      } else if (marker.getPosition && map.panTo) {
        map.panTo(marker.getPosition());
        const zoom = Math.max(map.getZoom(), options.zoom || 14);
        map.setZoom(zoom);
      }

      if (window._infoWindowTimer) {
        clearTimeout(window._infoWindowTimer);
        window._infoWindowTimer = null;
        // Ensure it's opaque if we interrupted a fade
        const iw = document.querySelector('.gm-style-iw-t');
        if (iw) iw.style.opacity = '1';
      }

      if (options.openPopup !== false && marker.openPopup) {
        marker.openPopup();
      } else if (options.openPopup !== false && window._infoWindow) {
        window._infoWindow.setContent(marker.popupContent);
        window._infoWindow.open(map, marker);
      }
      return true;
    } catch (e) {
      return false;
    }
  }

  function focusTeamWhenReady(teamName, options = {}) {
    if (focusTeam(teamName, options)) return;

    let attempts = 0;
    const iv = setInterval(() => {
      attempts++;
      if (focusTeam(teamName, options) || attempts > 20) {
        clearInterval(iv);
      }
    }, 150);
  }

  searchInput.addEventListener('input', applySearch);
  function closeFilterDropdown() {
    if (!filterButton || !filterDropdown || !filterMenu) return;
    filterButton.setAttribute('aria-expanded', 'false');
    filterDropdown.hidden = true;
    filterMenu.classList.remove('is-open');
  }

  function openFilterDropdown() {
    if (!filterButton || !filterDropdown || !filterMenu) return;
    filterButton.setAttribute('aria-expanded', 'true');
    filterDropdown.hidden = false;
    filterMenu.classList.add('is-open');
  }

  function resetFilters() {
    if (searchInput) searchInput.value = '';
    if (programFilter) programFilter.value = 'All';
    if (awardsFilter) awardsFilter.value = 'all';
    if (yearsFilter) yearsFilter.value = 'all';
    if (advancementFilter) advancementFilter.value = 'all';
    if (distanceFilter) distanceFilter.value = 'all';
    applySearch();
    closeFilterDropdown();
    searchInput.focus();
  }

  [programFilter, awardsFilter, yearsFilter, advancementFilter, distanceFilter].filter(Boolean).forEach((filterEl) => {
    filterEl.addEventListener('change', () => {
      applySearch();
    });
  });
  if (clearFiltersButton) {
    clearFiltersButton.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      resetFilters();
    });
  }
  if (filterButton && filterDropdown && filterMenu) {
    filterButton.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      const expanded = filterButton.getAttribute('aria-expanded') === 'true';
      if (expanded) {
        closeFilterDropdown();
      } else {
        openFilterDropdown();
      }
    });

    document.addEventListener('click', (event) => {
      if (filterMenu.contains(event.target)) return;
      closeFilterDropdown();
    });
  }

  function setTeamLayerVisible(teamName, visible) {
    const layerSet = (window._teamMapLayers || {})[teamName];
    const marker = (window._teamMarkers || {})[teamName];
    const map = window._teamsMapInstance;
    if (layerSet) {
      layerSet.visible = visible;
      [layerSet.circle, layerSet.privacyBlur].forEach(layer => {
        if (!layer || !map || !map.hasLayer || !map.addLayer || !map.removeLayer) return;
        if (visible && !map.hasLayer(layer)) {
          layer.addTo(map);
        } else if (!visible && map.hasLayer(layer)) {
          map.removeLayer(layer);
        }
      });
      if (!visible && layerSet.notifier && map && map.hasLayer(layerSet.notifier)) {
        map.removeLayer(layerSet.notifier);
      }
      if (visible && typeof window._updateTeamZoomNotifiers === 'function') {
        window._updateTeamZoomNotifiers();
      }
      if (typeof window._updatePrivacyBlur === 'function') {
        window._updatePrivacyBlur();
      }
      return;
    }

    if (!marker) return;

    if (marker.setVisible) {
      marker.setVisible(visible);
      return;
    }

    if (map && map.hasLayer && map.addLayer && map.removeLayer) {
      if (visible && !map.hasLayer(marker)) {
        marker.addTo(map);
      } else if (!visible && map.hasLayer(marker)) {
        map.removeLayer(marker);
      }
    }
  }

  function renderExpandableHistorySection({ title, iconClass, entries, sectionKey, sourceLink }) {
    const visibleEntries = entries.slice(0, 2);
    const hiddenEntries = entries.slice(2);
    const hasHiddenEntries = hiddenEntries.length > 0;
    const renderEntry = (entry, hidden = false) => {
      const displayEntry = sectionKey === 'awards' ? formatAwardHistoryDisplayEntry(entry) : entry;
      const icon = sectionKey === 'advancement' ? getAdvancementIconClass(entry) : iconClass;
      const toneClass = sectionKey === 'advancement' ? ` team-history-item--${getAdvancementToneClass(entry)}` : ' team-history-item--award';
      const meta = sectionKey === 'advancement' ? normalizeAdvancementLevel(entry) : 'Award';
      return `
        <li class="team-history-item${toneClass}"${hidden ? ' hidden data-history-hidden="true"' : ''}>
          <span class="team-history-entry">
            <span class="team-history-icon" aria-hidden="true"><i class="${escapeHTML(icon)}"></i></span>
            <span class="team-history-text">${escapeHTML(displayEntry)}</span>
            <span class="team-history-meta">${escapeHTML(meta)}</span>
          </span>
        </li>
      `;
    };

    return `
      <div class="team-card-award-history team-history-section" data-history-section="${escapeHTML(sectionKey)}">
        <strong><i class="${escapeHTML(iconClass)}" aria-hidden="true"></i> ${escapeHTML(title)}</strong>
        <ul class="team-history-list">
          ${visibleEntries.map((entry) => renderEntry(entry)).join('')}
          ${hiddenEntries.map((entry) => renderEntry(entry, true)).join('')}
        </ul>
        ${hasHiddenEntries ? `
          <button type="button" class="team-history-toggle" aria-expanded="false" aria-label="Show all ${escapeHTML(title).toLowerCase()}" data-history-toggle="false">
            <span class="team-history-toggle-icon" aria-hidden="true">...</span>
          </button>
        ` : ''}
        ${sourceLink ? `
          <a class="team-history-source-link" href="${escapeHTML(sourceLink.href)}" target="_blank" rel="noopener noreferrer">
            <i class="fa-solid fa-arrow-up-right-from-square" aria-hidden="true"></i>
            ${escapeHTML(sourceLink.label)}
          </a>
        ` : ''}
      </div>
    `;
  }

  orderedTeams.forEach(team => {
    const teamLat = Number(team.lat);
    const teamLon = Number(team.lon);
    const hasCoordinates = Number.isFinite(teamLat) && Number.isFinite(teamLon);
    const dist = userCoords && hasCoordinates ? haversineDistance(userCoords.lat, userCoords.lon, teamLat, teamLon) : null;
    const teamName = String(team.name || 'Unnamed team');
    const programLabel = String(team.program || 'FTC');
    const isNewTeam = Boolean(team.isNewTeam);
    const isRecruiting = isTeamRecruiting(team);
    const countryApplicationState = getCountryApplicationState(team);
    const teamNumber = isNewTeam
      ? 'New Team'
      : (team.teamNumber ? `${programLabel} ${team.teamNumber}` : `${programLabel} team`);
    const location = String(team.location || '').trim();
    const regionLabel = String(team.competitionRegionLabel || team.regionLabel || '').trim();
    const notes = String(team.notes || '').trim();
    const awards = String(team.awards || '').trim();
    const awardHistory = Array.isArray(team.awardHistory) ? team.awardHistory.filter(Boolean) : [];
    const yearsInProgram = Number(team.yearsInProgram);
    const advancementLevels = Array.isArray(team.advancementLevels) ? team.advancementLevels.map(normalizeAdvancementLevel).filter(Boolean) : [];
    const advancementHistory = Array.isArray(team.advancementHistory) ? team.advancementHistory.filter(Boolean) : [];
    const teamContact = String(team.contact || '').trim();
    const scoutingUrl = getTeamScoutingUrl(team);
    const scoutingLabel = programLabel === 'FTC' ? 'View on FTC Scout' : 'View on The Blue Alliance';
    const advancementEntries = advancementHistory.length
      ? advancementHistory.map((entry, index) => formatAdvancementEntry(entry, advancementLevels, index))
      : advancementLevels;
    const teamRequirementsText = notes || 'Add your team requirements, such as meeting schedule, grades accepted, skills needed, or application steps.';
    const distanceData = Number.isFinite(dist) ? formatDistance(dist, distanceUnitPreference) : null;

    const card = document.createElement('div');
    card.className = 'team-card';
    card.classList.add(isRecruiting ? 'team-card--recruiting' : 'team-card--not-recruiting');
    // attach team name to the DOM card for easy lookup from marker events
    card.dataset.team = teamName;
    card.dataset.program = programLabel;
    card.dataset.isNewTeam = isNewTeam ? 'true' : 'false';
    card.dataset.recruiting = isRecruiting ? 'true' : 'false';
    card.dataset.hasAwards = awards ? 'true' : 'false';
    card.dataset.yearsInProgram = Number.isFinite(yearsInProgram) ? String(yearsInProgram) : '';
    card.dataset.advancementLevels = advancementLevels.join('|');
    card.dataset.regionLabel = regionLabel;
    card.dataset.distanceKm = Number.isFinite(dist) ? String(dist) : '';
    card.dataset.search = `${teamName} ${teamNumber} ${location} ${regionLabel} ${notes} ${awards} ${awardHistory.join(' ')} ${advancementLevels.join(' ')} ${advancementHistory.join(' ')}`.toLowerCase();
    card.innerHTML = firstStartTrustedTypesPolicy.createHTML(`
      <div class="team-card-head">
        <div class="team-card-heading">
          <h3 class="team-card-title">${escapeHTML(teamName)}</h3>
          <span class="team-card-label${isNewTeam ? ' team-card-label--new-team' : ''}${isRecruiting ? '' : ' team-card-label--not-recruiting'}">${escapeHTML(teamNumber)}${regionLabel ? ` · ${escapeHTML(regionLabel)}` : ''}${isNewTeam ? ' · new team' : (team.verified ? ' · verified' : '')}${isRecruiting ? '' : ' · not recruiting'}</span>
          <span class="team-card-status-pill${isRecruiting ? ' team-card-status-pill--recruiting' : ' team-card-status-pill--not-recruiting'}">${escapeHTML(getTeamRecruitingLabel(team))}</span>
        </div>
        <div class="team-card-toolbar">
          <button class="btn btn-link goto-marker team-card-icon-button" title="Show on map" aria-label="Show ${escapeHTML(teamName)} on map" data-team="${escapeHTML(teamName)}"><i class="fa-solid fa-map-pin"></i></button>
          <button class="btn btn-link toggle-details team-card-icon-button" aria-expanded="false" aria-label="Toggle details"><i class="fa-solid fa-chevron-down"></i></button>
        </div>
      </div>
      <div class="team-details-content" style="margin-top: 12px; max-height: 0; overflow: hidden; opacity: 0; transition: max-height 260ms ease, opacity 200ms ease;">
        ${teamContact ? `<p class="team-card-contact">Contact <a href="mailto:${escapeHTML(teamContact)}">${escapeHTML(teamContact)}</a></p>` : '<p class="team-card-contact">Contact not set.</p>'}
        ${(location || regionLabel) ? `<p class="team-card-meta">${escapeHTML([location, regionLabel].filter(Boolean).join(' · '))}</p>` : ''}
        ${scoutingUrl ? `
          <p class="team-card-source">
            <a href="${escapeHTML(scoutingUrl)}" target="_blank" rel="noopener noreferrer">
              <i class="fa-solid fa-arrow-up-right-from-square" aria-hidden="true"></i>
              ${escapeHTML(scoutingLabel)}
            </a>
          </p>
        ` : ''}
        ${distanceData ? `<p class="team-distance"><span>Distance</span><strong>${distanceData.label} away</strong></p>` : ''}
        ${Number.isFinite(yearsInProgram) ? `
          <div class="team-card-stats">
            <div class="team-card-stat">
              <span class="team-card-stat-icon" aria-hidden="true">
                <i class="${yearsInProgram === 0 ? 'fa-solid fa-seedling' : 'fa-regular fa-calendar'}"></i>
              </span>
              <span class="team-card-stat-text">${yearsInProgram === 0 ? 'New Team Forming' : `${escapeHTML(String(yearsInProgram))} year${yearsInProgram === 1 ? '' : 's'} in program`}</span>
            </div>
          </div>
        ` : ''}
        <div class="team-card-requirements">
          <div class="team-card-requirements-head">
            <span class="team-card-requirements-icon" aria-hidden="true"><i class="fa-solid fa-list-check"></i></span>
            <span class="team-card-requirements-title">Team Requirements</span>
          </div>
          <p class="team-card-requirements-text">${escapeHTML(teamRequirementsText)}</p>
        </div>
        ${awardHistory.length ? `
          ${renderExpandableHistorySection({
            title: 'Awards achieved',
            iconClass: 'fa-solid fa-medal',
            entries: awardHistory,
            sectionKey: 'awards'
          })}
        ` : ''}
        ${advancementEntries.length ? `
          ${renderExpandableHistorySection({
            title: 'Competition History',
            iconClass: 'fa-solid fa-flag-checkered',
            entries: advancementEntries,
            sectionKey: 'advancement',
            sourceLink: scoutingUrl ? { href: scoutingUrl, label: scoutingLabel } : null
          })}
        ` : ''}
        <div class="team-actions">
          <button class="btn btn-primary send-btn"${!isRecruiting || countryApplicationState.outsideCountry ? ' disabled' : ''}>${!isRecruiting ? 'Not Recruiting' : countryApplicationState.needsCountry ? 'Add Country to Apply' : countryApplicationState.outsideCountry ? 'Outside Your Country' : 'Send My Info'}</button>
        </div>
      </div>
    `);
    window._teamCards[teamName] = card;

    const sendBtn = card.querySelector('.send-btn');
    if (sendBtn) sendBtn.addEventListener('click', (e) => { e.stopPropagation(); sendToTeam(team); });

    const gotoBtn = card.querySelector('.goto-marker');
    if (gotoBtn) gotoBtn.addEventListener('click', event => {
      event.stopPropagation();
      focusTeamWhenReady(teamName, { openPopup: true, zoom: 14 });
    });

    const toggleBtn = card.querySelector('.toggle-details');
    const detailsContent = card.querySelector('.team-details-content');
    const historyToggleButtons = card.querySelectorAll('.team-history-toggle');
    // start collapsed by default for a compact list view
    card.classList.add('collapsed');
    if (detailsContent) {
      // prepare for animated collapse via max-height (use display:block so scrollHeight is measurable)
      detailsContent.style.display = 'block';
      detailsContent.style.maxHeight = '0px';
      detailsContent.style.opacity = '0';
      detailsContent.style.overflow = 'hidden';
      detailsContent.style.transition = 'max-height 260ms ease, opacity 200ms ease';
    }

    historyToggleButtons.forEach((button) => {
      button.addEventListener('click', event => {
        event.stopPropagation();
        const section = button.closest('.team-history-section');
        if (!section) return;
        const isExpanded = button.getAttribute('aria-expanded') === 'true';
        const hiddenItems = section.querySelectorAll('li[data-history-hidden="true"]');

        hiddenItems.forEach((item) => {
          item.hidden = isExpanded;
        });

        const nextExpanded = !isExpanded;
        button.setAttribute('aria-expanded', String(nextExpanded));
        button.setAttribute('data-history-toggle', String(nextExpanded));
        const icon = button.querySelector('.team-history-toggle-icon');
        if (icon) {
          icon.textContent = nextExpanded ? '↑' : '...';
        }

        if (card.classList.contains('expanded') && detailsContent) {
          requestAnimationFrame(() => {
            detailsContent.style.maxHeight = detailsContent.scrollHeight + 'px';
          });
        }
      });
    });

    if (toggleBtn && detailsContent) {
      toggleBtn.addEventListener('click', event => {
        event.stopPropagation();
        const isOpen = card.classList.toggle('expanded');
        if (isOpen) {
          card.classList.remove('collapsed');
          toggleBtn.setAttribute('aria-expanded', 'true');
          // set maxHeight dynamically to allow transition
          detailsContent.style.maxHeight = detailsContent.scrollHeight + 'px';
          detailsContent.style.opacity = '1';
          // bring the whole card into view after layout expands
          setTimeout(() => {
            card.scrollIntoView({ behavior: 'smooth', block: 'start' });
          }, 40);
        } else {
          card.classList.add('collapsed');
          toggleBtn.setAttribute('aria-expanded', 'false');
          detailsContent.style.maxHeight = '0px';
          detailsContent.style.opacity = '0';
        }
      });

      // allow clicking the card head to toggle as well (but ignore goto/toggle clicks)
      const head = card.querySelector('.team-card-head');
      if (head) {
        head.addEventListener('click', (e) => {
          if (e.target.closest('.goto-marker') || e.target.closest('.toggle-details')) return;
          toggleBtn.click();
        });
      }
    }

    let hoverFocusTimer = null;
    card.addEventListener('mouseenter', (event) => {
      if (event.target.closest('.goto-marker') || event.target.closest('.toggle-details') || event.target.closest('.send-btn')) return;
      hoverFocusTimer = setTimeout(() => {
        focusTeamWhenReady(teamName, { openPopup: true, zoom: 14, scroll: true });
      }, 2000);
    });

    card.addEventListener('mouseleave', () => {
      if (hoverFocusTimer) {
        clearTimeout(hoverFocusTimer);
        hoverFocusTimer = null;
      }
    });

    // keep legacy behavior: use goto button to focus/open popup

    listEl.appendChild(card);
  });
  applySearch();

  // initialize Leaflet map when available
  function tryInitMap() {
    if (!window.L) {
      setTimeout(tryInitMap, 200);
      return;
    }

    if (window._teamsMapInstance) {
      // Stop any fitBounds transition before replacing the map after geolocation.
      if (window._teamsMapInstance.stop) window._teamsMapInstance.stop();
      if (window._teamsMapInstance.remove) window._teamsMapInstance.remove();
      window._teamsMapInstance = null;
    }

    const map = L.map('teamsMap', {
      center: [39.5, -98.35],
      zoom: 4,
      scrollWheelZoom: true
    });
    const privacyBlurZoom = 16;
    const notifierMaxZoom = 10;
    const privacyBlurLayers = [];
    const PrivacyBlurCircle = L.Layer.extend({
      initialize(latlng, radiusMeters) {
        this._latlng = L.latLng(latlng);
        this._radiusMeters = radiusMeters;
      },
      onAdd(layerMap) {
        this._map = layerMap;
        this._el = L.DomUtil.create('div', 'team-privacy-blur');
        layerMap.getPanes().overlayPane.appendChild(this._el);
        layerMap.on('zoom viewreset move', this._reset, this);
        this._reset();
      },
      onRemove(layerMap) {
        layerMap.off('zoom viewreset move', this._reset, this);
        if (this._el) L.DomUtil.remove(this._el);
        this._map = null;
        this._el = null;
      },
      setVisible(visible) {
        if (this._el) this._el.classList.toggle('is-visible', visible);
      },
      _reset() {
        if (!this._map || !this._el) return;
        const center = this._map.latLngToLayerPoint(this._latlng);
        const lngOffset = this._radiusMeters / (111320 * Math.cos(this._latlng.lat * Math.PI / 180));
        const edge = this._map.latLngToLayerPoint([this._latlng.lat, this._latlng.lng + lngOffset]);
        const radiusPx = Math.max(8, Math.abs(edge.x - center.x));
        const size = radiusPx * 2;

        this._el.style.width = `${size}px`;
        this._el.style.height = `${size}px`;
        L.DomUtil.setPosition(this._el, center.subtract([radiusPx, radiusPx]));
      }
    });
    const updatePrivacyBlur = () => {
      const shouldBlur = map.getZoom() >= privacyBlurZoom;
      privacyBlurLayers.forEach(layer => layer.setVisible(shouldBlur));
    };
    const updateTeamZoomNotifiers = () => {
      const shouldShow = map.getZoom() <= notifierMaxZoom;
      Object.values(window._teamMapLayers || {}).forEach(layerSet => {
        if (!layerSet.notifier) return;
        const onMap = map.hasLayer(layerSet.notifier);
        if (shouldShow && layerSet.visible !== false && !onMap) {
          layerSet.notifier.addTo(map);
        } else if ((!shouldShow || layerSet.visible === false) && onMap) {
          map.removeLayer(layerSet.notifier);
        }
      });
    };
    window._updatePrivacyBlur = updatePrivacyBlur;
    window._updateTeamZoomNotifiers = updateTeamZoomNotifiers;

    const mapTiles = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap contributors',
      updateWhenIdle: true,
      updateWhenZooming: false,
      keepBuffer: 1
    });

    window._teamsMapInstance = map;
    window._infoWindowTimer = null;
    window._pinnedTeamPopup = null;
    window._teamMapLayers = {};
    window._teamMarkers = {};
    window._userLocationMarker = null;

    const bounds = L.latLngBounds();
    window._userLocationMarker = createUserLocationMarker(map, userCoords, bounds);

    teams.forEach(team => {
      const teamLat = Number(team.lat);
      const teamLon = Number(team.lon);
      if (!Number.isFinite(teamLat) || !Number.isFinite(teamLon)) return;
      if (team.registered === false) return;

      const teamName = String(team.name || 'Unnamed team');
      const programLabel = String(team.program || 'FTC');
      const isNewTeam = Boolean(team.isNewTeam);
      const isRecruiting = isTeamRecruiting(team);
      const countryApplicationState = getCountryApplicationState(team);
      const dist = userCoords ? haversineDistance(userCoords.lat, userCoords.lon, teamLat, teamLon) : null;
      const distanceData = Number.isFinite(dist) ? formatDistance(dist, distanceUnitPreference) : null;
      const location = String(team.location || '').trim();
      const teamContact = String(team.contact || '').trim();
      const radiusMeters = Number(team.radiusMeters) || 1000;

      const popupContent = `
        <div style="padding: 2px 15px 15px 15px; color: #111; font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; min-width: 220px; line-height: 1.4;">
      <h4 style="margin: 0 0 10px 0; font-size: 1.8em; font-weight: 900; color: #0056b3; line-height: 1.15; padding-top: 0;">${escapeHTML(teamName)}</h4>
          ${isNewTeam ? `<p style="margin: 0 0 6px 0; font-size: 1.1em; font-weight: 700; color: #333;">New Team</p>` : (team.teamNumber ? `<p style="margin: 0 0 6px 0; font-size: 1.1em; font-weight: 700; color: #333;">${escapeHTML(programLabel)} ${escapeHTML(team.teamNumber)}</p>` : '')}
          ${location ? `<p style="margin: 0 0 10px 0; font-size: 0.95em; font-weight: 600; color: #444;">${escapeHTML(location)}</p>` : ''}
          <p style="margin: 0 0 10px 0; font-size: 0.98em; font-weight: 900; color: ${isRecruiting ? '#1f6f45' : '#4b5563'};">${getTeamRecruitingLabel(team)}</p>
          <p style="margin: 0 0 12px 0; font-size: 0.95em; font-weight: 700; color: #0056b3;">Approximate ${escapeHTML(radiusMeters)}-meter area</p>
          <div style="margin-bottom: 12px;">
            <p style="margin: 0; font-size: 0.9em; font-weight: 800; color: #555; text-transform: uppercase;">Contact</p>
            ${teamContact ? `<p style="margin: 0; font-size: 1em; font-weight: 600; color: #222;"><a href="mailto:${escapeHTML(teamContact)}" style="color: inherit; text-decoration: underline;">${escapeHTML(teamContact)}</a></p>` : '<p style="margin: 0; font-size: 1em; font-weight: 600; color: #222;">Contact email not listed</p>'}
          </div>
          ${distanceData ? `<p style="margin: 0 0 15px 0; font-size: 1em; font-weight: 800; color: #d32f2f;">${distanceData.label} away</p>` : ''}
          <button class="popup-send-btn btn btn-primary" style="width: 100%; font-weight: 800; padding: 10px; border-radius: 6px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); border: none;" data-team="${escapeHTML(teamName)}"${!isRecruiting || countryApplicationState.outsideCountry ? ' disabled' : ''}>${!isRecruiting ? 'Not Recruiting' : countryApplicationState.needsCountry ? 'Add Country to Apply' : countryApplicationState.outsideCountry ? 'Outside Your Country' : 'Send My Info'}</button>
        </div>
      `;

      const marker = L.circle([teamLat, teamLon], {
        radius: radiusMeters,
        color: isRecruiting ? '#0056b3' : '#4b5563',
        weight: 2,
        opacity: 0.95,
        fillColor: isRecruiting ? '#2f80ed' : '#9ca3af',
        fillOpacity: isRecruiting ? 0.18 : 0.34,
        bubblingMouseEvents: false
      }).addTo(map);
      const privacyBlurLayer = new PrivacyBlurCircle([teamLat, teamLon], radiusMeters).addTo(map);
      privacyBlurLayers.push(privacyBlurLayer);
      const notifier = L.marker([teamLat, teamLon], {
        interactive: true,
        keyboard: true,
        title: `${teamName} is in this area`,
        icon: L.divIcon({
          className: 'team-zoom-notifier-icon',
          html: `<span class="team-zoom-notifier${isRecruiting ? '' : ' team-zoom-notifier--inactive'}" aria-hidden="true"></span>`,
          iconSize: [28, 36],
          iconAnchor: [14, 34],
          popupAnchor: [0, -34]
        })
      });

      marker.bindPopup(popupContent, { maxWidth: 320 });
      if (!window._teamMarkers) window._teamMarkers = {};
      window._teamMarkers[teamName] = marker;
      if (!window._teamMapLayers) window._teamMapLayers = {};
      window._teamMapLayers[teamName] = {
        circle: marker,
        notifier,
        privacyBlur: privacyBlurLayer,
        visible: true
      };

      marker.on('mouseover', () => {
        if (window._pinnedTeamPopup) return;
        if (window._infoWindowTimer) {
          clearTimeout(window._infoWindowTimer);
          window._infoWindowTimer = null;
        }
        marker.openPopup();
      });

      marker.on('mouseout', () => {
        if (window._pinnedTeamPopup && window._pinnedTeamPopup.marker === marker) return;
        window._infoWindowTimer = setTimeout(() => {
          marker.closePopup();
          window._infoWindowTimer = null;
        }, 500);
      });

      marker.on('click', (event) => {
        if (window.L && L.DomEvent && event && event.originalEvent) {
          L.DomEvent.stopPropagation(event.originalEvent);
        }
        window._pinnedTeamPopup = { teamName, marker };
        focusTeam(teamName, { scroll: true, openPopup: true });
      });
      notifier.on('click', (event) => {
        if (window.L && L.DomEvent && event && event.originalEvent) {
          L.DomEvent.stopPropagation(event.originalEvent);
        }
        window._pinnedTeamPopup = { teamName, marker };
        focusTeam(teamName, { scroll: true, openPopup: true, zoom: 12 });
      });

      bounds.extend(marker.getBounds());
    });

    if (userCoords && typeof userCoords.lat === 'number' && typeof userCoords.lon === 'number') {
      map.setView([userCoords.lat, userCoords.lon], 12, { animate: false });
    } else if (bounds.isValid()) {
      map.fitBounds(bounds, { padding: [24, 24], animate: false });
    } else if (window._userLocationMarker && userCoords) {
      map.setView([userCoords.lat, userCoords.lon], 13, { animate: false });
    }
    // Add tiles only after the final initial viewport is known. This avoids
    // downloading one tile set for the default view and another for fitBounds.
    mapTiles.addTo(map);
    updatePrivacyBlur();
    updateTeamZoomNotifiers();
    map.on('zoomend', updatePrivacyBlur);
    map.on('zoomend', updateTeamZoomNotifiers);
    map.on('click', () => {
      window._pinnedTeamPopup = null;
      if (window._infoWindowTimer) {
        clearTimeout(window._infoWindowTimer);
        window._infoWindowTimer = null;
      }
      map.closePopup();
    });

    map.on('popupopen', event => {
      const popupEl = event.popup && event.popup.getElement ? event.popup.getElement() : null;
      if (popupEl && window.L && L.DomEvent) {
        L.DomEvent.disableClickPropagation(popupEl);
      }
      const btn = popupEl ? popupEl.querySelector('.popup-send-btn') : null;
      if (btn) {
        btn.onclick = () => {
          const teamName = btn.getAttribute('data-team');
          const team = teams.find(t => t.name === teamName);
          if (team) sendToTeam(team);
        };
      }
    });

    applySearch();
  }

  tryInitMap();
}

async function sendToTeam(team) {
  const currentUser = getCurrentUser();
  if (!currentUser) {
    redirectToAuthGate(window.location.pathname || '/teams-nearby', 'Send My Info');
    return;
  }

  const countryApplicationState = getCountryApplicationState(team);
  if (countryApplicationState.needsCountry) {
    window.location.href = '/account/signup-info';
    return;
  }
  if (countryApplicationState.outsideCountry) {
    alert('You can only apply to teams in your country.');
    return;
  }

  try {
    const response = await fetch('/api/signups', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        teamId: team && (team.id || team._id)
      })
    });

    const payload = await response.json().catch(() => ({}));
    if (!response.ok) {
      alert(payload && payload.error ? payload.error : 'Unable to save your application right now.');
      return;
    }

    alert(`Your info was sent to ${team.name || 'the team'}.`);
  } catch (err) {
    alert('Unable to save your application right now.');
    if (err && err.message) {
      console.error('Unable to save your application right now:', err);
    }
    return;
  }
}

function initTeamsPage() {
  const container = document.getElementById('teamsContainer');
  if (!container) return;

  const teams = Array.isArray(window.__TEAMS__)
    ? window.__TEAMS__.map(team => ({
      ...team,
      lat: Number(team.lat),
      lon: Number(team.lon)
    }))
    : [];
  const coords = window.__USER_COORDS__ || null;
  const status = document.getElementById('teamsStatus');
  const zipForm = document.getElementById('zipLocationForm');
  const zipInput = document.getElementById('zipLocationInput');
  const zipMessage = document.getElementById('zipLocationMessage');
  const initialQuery = String(new URLSearchParams(window.location.search).get('q') || '').trim();
  if (!teams.length) {
    status.textContent = 'Team listings are temporarily unavailable. Please try again shortly.';
    renderTeams([], null);
    return;
  }

  status.textContent = 'Loading teams…';

  if (zipInput && initialQuery) {
    zipInput.value = initialQuery;
  }

  renderTeams(teams, coords);

  function setZipMessage(message, isError = false) {
    if (!zipMessage) return;
    zipMessage.textContent = message || '';
    zipMessage.classList.toggle('is-error', Boolean(isError));
  }

  function hasTeamWithinMiles(referenceCoords, radiusMiles) {
    if (!referenceCoords || typeof referenceCoords.lat !== 'number' || typeof referenceCoords.lon !== 'number') return false;
    const radiusKm = radiusMiles / 0.621371;
    return teams.some(team => (
      team
      && typeof team.lat === 'number'
      && typeof team.lon === 'number'
      && haversineDistance(referenceCoords.lat, referenceCoords.lon, team.lat, team.lon) <= radiusKm
    ));
  }

  function updateLocationStatus(referenceCoords, nearbyMessage) {
    status.textContent = hasTeamWithinMiles(referenceCoords, 100)
      ? nearbyMessage
      : "Sorry, we don't find any registered team at your location";
  }

  async function lookupLocation(query) {
    const trimmed = String(query || '').trim();
    if (!trimmed) {
      throw new Error('Enter a city, county, state, country, or ZIP code.');
    }

    const endpoint = /^\d{5}$/.test(trimmed) ? `/api/geocode-zip?zip=${encodeURIComponent(trimmed)}` : `/api/geocode-location?q=${encodeURIComponent(trimmed)}`;
    const response = await fetch(endpoint, { credentials: 'same-origin' });
    const payload = await response.json().catch(() => ({}));

    if (!response.ok || !payload.ok || !payload.coords) {
      throw new Error(payload.error || 'Could not find that location.');
    }

    const locationCoords = {
      lat: Number(payload.coords.lat),
      lon: Number(payload.coords.lon)
    };

    if (!Number.isFinite(locationCoords.lat) || !Number.isFinite(locationCoords.lon)) {
      throw new Error('Could not find that location.');
    }

    return {
      coords: locationCoords,
      label: payload.displayName || trimmed
    };
  }

  if (zipForm && zipInput) {
    zipForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const query = zipInput.value.trim();

      if (!query) {
        setZipMessage('Enter a city, county, state, country, or ZIP code.', true);
        zipInput.focus();
        return;
      }

      setZipMessage('Looking up location...');

      try {
        const location = await lookupLocation(query);
        renderTeams(teams, location.coords);
        updateLocationStatus(location.coords, `Showing teams near ${location.label}`);
        setZipMessage('');
      } catch (err) {
        setZipMessage(err && err.message ? err.message : 'Unable to look up that location right now.', true);
      }
    });
  }

  if (initialQuery) {
    lookupLocation(initialQuery)
      .then((location) => {
        renderTeams(teams, location.coords);
        updateLocationStatus(location.coords, `Showing teams near ${location.label}`);
        setZipMessage('');
      })
      .catch((err) => {
        setZipMessage(err && err.message ? err.message : 'Unable to look up that location right now.', true);
      });
  }

  if (!initialQuery) {
    status.textContent = 'Showing recruiting teams';
    setZipMessage('Enter a city, county, state, country, or ZIP code to sort by approximate distance.');
  }
}

function getTeamAccent(team, index = 0) {
  const palette = [
    '#0f766e',
    '#2563eb',
    '#7c3aed',
    '#be123c',
    '#c2410c',
    '#047857',
    '#4338ca',
    '#b45309',
    '#0e7490',
    '#a21caf',
    '#15803d',
    '#1d4ed8'
  ];
  return palette[index % palette.length];
}

function getHomeTeamTitle(team) {
  if (team && (team.isNewTeam || !team.teamNumber)) return 'New Team';
  return team && team.teamNumber ? `#${team.teamNumber}` : 'Team';
}

function getHomeTeamYearsLabel(team) {
  const years = Number(team && team.yearsInProgram);
  if (team && (team.isNewTeam || !Number.isFinite(years) || years <= 0)) {
    return 'New Team Forming';
  }
  if (Number.isFinite(years)) {
    return `${years} year${years === 1 ? '' : 's'} in program`;
  }
  return 'Years not listed';
}

function getHomeTeamDescription(team) {
  const note = String(team && team.notes ? team.notes : '').trim();
  if (note) return note;
  if (team && team.isNewTeam) return 'A new team forming and looking for students nearby.';
  return 'View this recruiting team and see what they are looking for in students.';
}

function getHomeTeamBadgeLabel(team) {
  const rawName = String(team && team.name ? team.name : '').trim();
  if (rawName) {
    const words = rawName.split(/\s+/).filter(Boolean);
    const initials = words.slice(0, 2).map(word => word.charAt(0)).join('');
    if (initials) return initials;
  }
  if (team && team.program) {
    return String(team.program).trim().slice(0, 2);
  }
  if (team && team.teamNumber) {
    return String(team.teamNumber).slice(0, 2);
  }
  return 'FT';
}

function getTeamScoutingUrl(team) {
  if (!team || team.isNewTeam || !team.teamNumber) return null;
  const program = String(team.program || 'FTC').trim().toUpperCase();
  const teamNumber = encodeURIComponent(String(team.teamNumber));

  if (program === 'FTC') {
    return `https://ftcscout.org/teams/${teamNumber}`;
  }

  if (program === 'FRC') {
    return `https://www.thebluealliance.com/team/${teamNumber}`;
  }

  return null;
}

function renderHomeFeaturedTeams(teams) {
  const grid = document.getElementById('homeFeaturedTeams');
  if (!grid || !Array.isArray(teams) || !teams.length) return;

  const distanceUnitPreference = getDistanceUnitPreference();
  const orderedTeams = teams.slice().sort((left, right) => {
    const leftDistance = Number(left && left.distance);
    const rightDistance = Number(right && right.distance);
    const leftHasDistance = Number.isFinite(leftDistance);
    const rightHasDistance = Number.isFinite(rightDistance);
    if (!leftHasDistance && !rightHasDistance) return 0;
    if (!leftHasDistance) return 1;
    if (!rightHasDistance) return -1;
    return leftDistance - rightDistance;
  });

  grid.innerHTML = firstStartTrustedTypesPolicy.createHTML(orderedTeams.map((team, index) => {
    const accent = getTeamAccent(team, index);
    const location = [team.city, team.state, team.country].filter(Boolean).join(', ') || 'Location not listed';
    const distance = Number.isFinite(team.distance) ? formatDistance(team.distance, distanceUnitPreference).label : null;
    const numberLabel = getHomeTeamTitle(team);
    const yearsLabel = getHomeTeamYearsLabel(team);
    const isRecruiting = isTeamRecruiting(team);
    const statusLabel = isRecruiting ? 'Recruiting' : 'Not recruiting';
    const verifiedLabel = team.verified ? 'Verified' : 'Listed';
    const programLabel = team.program || 'FTC';
    const description = getHomeTeamDescription(team);
    const badgeLabel = getHomeTeamBadgeLabel(team);
    const barStyle = `background-color: ${accent};`;
    const numberStyle = `border-color: ${accent}33; background-color: ${accent}15; color: ${accent};`;
    const logoStyle = `border-color: ${accent}33; background-color: ${accent}12; color: ${accent};`;

    return `
      <article class="team-card" style="--team-accent: ${accent};">
        <div class="team-card-bar" style="${barStyle}"></div>
        <div class="team-card-body">
          <div class="team-card-top">
            <div class="team-card-brand">
              <div class="team-logo-badge" style="${logoStyle}">${escapeHTML(badgeLabel)}</div>
              <div class="team-number" style="${numberStyle}">${escapeHTML(numberLabel)}</div>
            </div>
            <span class="league-pill">${escapeHTML(programLabel)}</span>
          </div>
          <h3>${escapeHTML(team.name || 'Team')}</h3>
          <p class="team-location"><i class="fa-solid fa-map-pin" aria-hidden="true"></i> ${escapeHTML(location)}</p>
          <p class="team-description">${escapeHTML(description)}</p>
          <div class="team-meta">
            <span><span class="team-meta-icon" aria-hidden="true"><i class="fa-solid fa-location-crosshairs" aria-hidden="true"></i></span> ${escapeHTML(distance ? `${distance} away` : location)}</span>
            <span><span class="team-meta-icon" aria-hidden="true"><i class="fa-solid fa-calendar-days" aria-hidden="true"></i></span> ${escapeHTML(yearsLabel)}</span>
          </div>
          <div class="team-roles">
            <span>${escapeHTML(statusLabel)}</span>
            <span>${escapeHTML(verifiedLabel)}</span>
            <span>${escapeHTML(team.isNewTeam ? 'New Team' : 'Established')}</span>
          </div>
          <a href="/teams-nearby" class="team-button">View Team &amp; Apply</a>
        </div>
      </article>
    `;
  }).join(''));
}

function initHomeFeaturedTeams() {
  // Featured teams stay server-rendered. Users can search by city or ZIP;
  // precise browser location is never requested automatically.
}

// Signup page: toggle between seeker (join/make) and manager flows
function initSignupForm() {
  const form = document.getElementById('signupForm');
  if (!form) return;

  const modeButtons = document.querySelectorAll('.signup-mode');
  const modeInput = form.querySelector('#signupMode') || form.querySelector('input[name="signupMode"]');
  const managerContainer = form.querySelector('.signup-manager-fields');
  const seekerContainer = form.querySelector('.signup-seeker-fields');
  const currentUrl = new URL(window.location.href);
  currentUrl.hash = '';
  currentUrl.searchParams.delete('nocache');
  const currentPath = `${currentUrl.pathname}${currentUrl.search}`;
  const draftKey = `signup_draft:${currentPath}`;
  const returnKey = 'signup_terms_return_url';

  function captureDraft() {
    try {
      const payload = {};
      new FormData(form).forEach((value, key) => {
        payload[key] = value;
      });
      sessionStorage.setItem(draftKey, JSON.stringify(payload));
      sessionStorage.setItem(returnKey, currentPath);
    } catch (e) {}
  }

  function restoreDraft() {
    try {
      const raw = sessionStorage.getItem(draftKey);
      if (!raw) return;
      const payload = JSON.parse(raw);
      form.querySelectorAll('input, textarea, select').forEach((el) => {
        if (!el.name || !(el.name in payload)) return;
        if (el.type === 'checkbox' || el.type === 'radio') {
          const values = Array.isArray(payload[el.name]) ? payload[el.name].map(String) : [String(payload[el.name])];
          el.checked = values.includes(el.value);
        } else if (el.tagName === 'SELECT' || el.tagName === 'TEXTAREA') {
          el.value = String(payload[el.name]);
        } else if (el.type !== 'hidden') {
          el.value = String(payload[el.name]);
        }
      });
    } catch (e) {}
  }

  function setMode(mode) {
    modeButtons.forEach(btn => btn.classList.toggle('active', btn.dataset.mode === mode));
    if (modeInput) modeInput.value = mode;
    if (managerContainer) managerContainer.style.display = mode === 'manager' ? '' : 'none';
    if (seekerContainer) seekerContainer.style.display = mode === 'manager' ? 'none' : '';

    if (managerContainer) {
      managerContainer.querySelectorAll('input, textarea, select').forEach(el => el.disabled = mode !== 'manager');
    }
    if (seekerContainer) {
      seekerContainer.querySelectorAll('input, textarea, select').forEach(el => el.disabled = mode === 'manager');
    }

    try { sessionStorage.setItem('signup_intent', mode); } catch (e) {}
  }

  restoreDraft();
  form.querySelectorAll('input, textarea, select').forEach(el => {
    el.addEventListener('input', captureDraft);
    el.addEventListener('change', captureDraft);
  });

  const termsButton = form.querySelector('.terms-button');
  if (termsButton) {
    termsButton.setAttribute('href', '/terms#usercentrics-ppg');
    termsButton.addEventListener('click', captureDraft);
  }

  if (modeButtons && modeButtons.length > 0) {
    modeButtons.forEach(btn => btn.addEventListener('click', () => setMode(btn.dataset.mode)));
    // initialize default mode for combined page
    setMode('seeker');
  } else if (modeInput) {
    // standalone seeker/manager pages: respect server-provided hidden input or path
    const initial = modeInput.value || (window.location.pathname && window.location.pathname.includes('/signup/manager') ? 'manager' : 'seeker');
    // ensure containers/fields reflect the initial mode without overwriting server values
    if (managerContainer) managerContainer.style.display = initial === 'manager' ? '' : 'none';
    if (seekerContainer) seekerContainer.style.display = initial === 'manager' ? 'none' : '';
    if (managerContainer) managerContainer.querySelectorAll('input, textarea, select').forEach(el => el.disabled = initial !== 'manager');
    if (seekerContainer) seekerContainer.querySelectorAll('input, textarea, select').forEach(el => el.disabled = initial === 'manager');
    try { sessionStorage.setItem('signup_intent', initial); } catch (e) {}
  }
}

function initTermsPage() {
  const backLink = document.querySelector('[data-terms-back-link]');
  if (!backLink) return;

  try {
    const returnUrl = sessionStorage.getItem('signup_terms_return_url');
    if (returnUrl) backLink.setAttribute('href', returnUrl);
  } catch (e) {}
}

// Initialize on load
document.addEventListener('DOMContentLoaded', () => {
  initDeclarativeActions();
  initPageAnimations();
  loadSharedFooter();
  loadSiteShells();
  initJoinForm();
  initAuthGatedActions();
  initHomeFeaturedTeams();
  initTeamsPage();
  initSignupForm();
  initTermsPage();
});

function loadSharedFooter() {
  if (document.querySelector('.home-footer') || document.querySelector('.site-footer')) return;
  fetch('/assets/partial/footer.html')
    .then(r => r.text())
    .then(html => {
      const footerTemplate = document.createElement('template');
      footerTemplate.innerHTML = firstStartTrustedTypesPolicy.createHTML(html.trim());
      const footer = footerTemplate.content.firstElementChild;
      if (footer) document.body.appendChild(footer);
      const yearEl = document.getElementById('site-year');
      if (yearEl) yearEl.textContent = new Date().getFullYear();
    })
    .catch(() => {});
}

// Initialize the shared site shell. Server-rendered pages already include it;
// the fetch remains as a fallback for standalone/static documents.
function loadSiteShells() {
  // Keep a local fallback for pages that are not rendered through Express.
  if (!document.body.classList.contains('home-page') && !document.querySelector('link[href*="bootstrap.min.css"]')) {
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = '/assets/vendor/bootstrap/bootstrap.min.css?v=3.3.6';
    const appStylesheet = document.querySelector('link[href*="/assets/css/main.css"], link[href*="assets/css/main.css"]');
    document.head.insertBefore(link, appStylesheet || document.head.firstChild);
  }

  const headerReady = document.querySelector('header .navbar, body > .navbar')
    ? Promise.resolve()
    : fetch('/assets/partial/header.html?v=46')
      .then(r => r.text())
      .then(html => {
        const header = document.querySelector('header');
        if (header) {
          header.innerHTML = firstStartTrustedTypesPolicy.createHTML(html);
        } else {
          const h = document.createElement('div');
          h.innerHTML = firstStartTrustedTypesPolicy.createHTML(html);
          document.body.insertBefore(h, document.body.firstChild);
        }
      });

    headerReady.then(() => {

      // Immediately rewrite all links so they work even while auth is loading
      const initialAnchors = document.querySelectorAll('[data-href]');
      const gatedTargets = new Set(['/my-applications', '/team-register']);
      initialAnchors.forEach(a => {
        const target = a.getAttribute('data-href');
        if (!target) return;
        if (gatedTargets.has(target)) {
          const label = encodeURIComponent((a.textContent || '').trim());
          a.setAttribute('href', `/auth-gate?next=${encodeURIComponent(target)}${label ? `&label=${label}` : ''}`);
        } else {
          a.setAttribute('href', target);
        }
      });

      function bindNavbarDrawer() {
        const toggle = document.querySelector('[data-navbar-toggle]');
        const drawer = document.querySelector('[data-navbar-collapse]');
        if (!toggle || !drawer) return;

        const mobileQuery = window.matchMedia ? window.matchMedia('(max-width: 1120px)') : null;

        function syncDrawerState() {
          const isMobile = mobileQuery ? mobileQuery.matches : window.innerWidth <= 1120;
          const isOpen = drawer.classList.contains('is-open');

          if (!isMobile) {
            drawer.hidden = false;
            drawer.classList.remove('is-open');
            toggle.setAttribute('aria-expanded', 'false');
            return;
          }

          drawer.hidden = !isOpen;
          toggle.setAttribute('aria-expanded', String(isOpen));
        }

        if (!toggle.dataset.bound) {
          toggle.dataset.bound = 'true';
          toggle.addEventListener('click', (event) => {
            event.preventDefault();
            event.stopPropagation();
            const isOpen = drawer.classList.contains('is-open');
            drawer.classList.toggle('is-open', !isOpen);
            drawer.hidden = isOpen;
            toggle.setAttribute('aria-expanded', String(!isOpen));
          });
        }

        if (!window.__navbarDrawerListenerBound) {
          window.__navbarDrawerListenerBound = true;
          document.addEventListener('click', (event) => {
            if (!drawer.classList.contains('is-open')) return;
            if (drawer.contains(event.target) || toggle.contains(event.target)) return;
            drawer.classList.remove('is-open');
            drawer.hidden = true;
            toggle.setAttribute('aria-expanded', 'false');
          });
        }

        if (mobileQuery && !toggle.dataset.breakpointBound) {
          toggle.dataset.breakpointBound = 'true';
          mobileQuery.addEventListener('change', syncDrawerState);
        }

        window.addEventListener('resize', syncDrawerState, { passive: true });
        syncDrawerState();
        window.requestAnimationFrame(syncDrawerState);
        window.setTimeout(syncDrawerState, 0);
      }

      bindNavbarDrawer();

      // Anonymous pages can initialize immediately without an extra API request.
      const authRequest = document.documentElement.dataset.authState === 'anonymous'
        ? Promise.resolve({ user: null, notifications: [], unreadCount: 0 })
        : fetch('/api/users/me').then(r => r.json());

      // Update links and toggle visibility based on auth status.
      authRequest
        .then(data => { 
          const user = data.user;
          window.__USER__ = user || null;
          const anchors = document.querySelectorAll('[data-href]');
          const navUserControls = document.querySelector('.nav-user-controls');
          const inboxMenu = document.querySelector('.inbox-menu');
          const inboxToggle = document.querySelector('[data-inbox-toggle]');
          const inboxDropdown = document.querySelector('[data-inbox-dropdown]');
          const inboxList = document.querySelector('[data-inbox-list]');
          const inboxEmpty = document.querySelector('[data-inbox-empty]');
          const inboxTitle = document.querySelector('[data-inbox-title]');
          const inboxClear = document.querySelector('[data-inbox-clear]');
          const accountMenu = document.querySelector('.account-menu');
          const accountToggle = document.querySelector('[data-account-toggle]');
          const accountDropdown = document.querySelector('[data-account-dropdown]');
          const initialsEl = document.querySelector('[data-account-initials]');
          const accountLabelEl = document.querySelector('.account-label');
          const inboxCountEls = document.querySelectorAll('[data-inbox-count]');
          const statsLink = accountDropdown ? accountDropdown.querySelector('a[data-href="/stats"]') : null;
          const settingsLink = accountDropdown ? accountDropdown.querySelector('a[data-href="/account"]') : null;
          const signOutLink = accountDropdown ? accountDropdown.querySelector('a[data-href="/logout"]') : null;
          let notifications = Array.isArray(data.notifications) ? data.notifications : [];
          let unreadCount = Number.isFinite(Number(data.unreadCount)) ? Number(data.unreadCount) : 0;
          const canViewTeamEmailDirectory = Boolean(user && (
            user.canViewTeamEmailDirectory
            || String(user.email || '').trim().toLowerCase() === 'evergreentechatrons.contact@gmail.com'
          ));

          function formatNotificationDate(value) {
            const date = value ? new Date(value) : null;
            if (!date || Number.isNaN(date.getTime())) return '';
            return date.toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
          }

          function syncUnreadCount(nextCount) {
            unreadCount = Math.max(0, Number(nextCount) || 0);
            inboxCountEls.forEach((el) => {
              el.textContent = el.classList.contains('inbox-dropdown-count')
                ? (unreadCount > 0 ? `${unreadCount} new` : 'All caught up')
                : String(unreadCount);
            });
          }

          function updateInboxControls() {
            if (!inboxClear) return;
            const hasNotifications = notifications.length > 0;
            inboxClear.disabled = !hasNotifications;
            inboxClear.classList.toggle('is-disabled', !hasNotifications);
          }

          function renderNotifications() {
            if (!inboxList || !inboxEmpty || !inboxTitle) return;

            if (!notifications.length) {
              inboxList.replaceChildren();
              inboxEmpty.hidden = false;
              inboxTitle.textContent = 'Inbox';
              updateInboxControls();
              return;
            }

            inboxEmpty.hidden = true;
            inboxTitle.textContent = unreadCount > 0 ? 'New notifications' : 'Notifications';
            inboxList.innerHTML = firstStartTrustedTypesPolicy.createHTML(notifications.map((notification) => {
              const link = notification.link || '/account';
              const title = escapeHTML(notification.title || 'Notification');
              const body = escapeHTML(notification.body || '');
              const meta = formatNotificationDate(notification.createdAt);
              const isRead = Boolean(notification.readAt);
              return `
                <a class="inbox-dropdown-item ${isRead ? 'is-read' : ''}" href="${escapeHTML(link)}" data-notification-link>
                  <strong>${title}</strong>
                  <span>${body}</span>
                  ${meta ? `<span class="inbox-dropdown-item-meta">${escapeHTML(meta)}</span>` : ''}
                </a>
              `;
            }).join(''));
            updateInboxControls();
          }

          renderNotifications();
          syncUnreadCount(unreadCount);

          if (navUserControls) navUserControls.style.display = user ? 'inline-flex' : 'none';
          if (inboxToggle) inboxToggle.setAttribute('aria-expanded', 'false');
          if (inboxDropdown) inboxDropdown.hidden = true;
          if (accountToggle) accountToggle.setAttribute('aria-expanded', 'false');
          if (accountDropdown) accountDropdown.hidden = true;
          if (initialsEl && user) {
            const initials = user.name
              ? user.name
                .split(/\s+/)
                .filter(Boolean)
                .slice(0, 2)
                .map(part => part[0].toUpperCase())
                .join('') || 'U'
              : 'U';
            if (user.profilePicture) {
              initialsEl.innerHTML = firstStartTrustedTypesPolicy.createHTML(`<img src="${escapeHTML(user.profilePicture)}" alt="Profile picture">`);
            } else {
              initialsEl.textContent = initials;
            }
          } else if (initialsEl) {
            initialsEl.textContent = 'U';
          }

          if (user) {
            if (accountLabelEl) accountLabelEl.textContent = 'Account';
            renderNotifications();
            syncUnreadCount(unreadCount);
            if (settingsLink) {
              settingsLink.setAttribute('href', '/account');
              settingsLink.setAttribute('data-href', '/account');
              settingsLink.textContent = 'Settings';
            }
            if (signOutLink) {
              signOutLink.setAttribute('href', '/logout');
              signOutLink.setAttribute('data-href', '/logout');
              signOutLink.textContent = 'Sign Out';
            }
            if (statsLink) {
              const canViewStats = Boolean(user.canViewStats);
              statsLink.style.display = canViewStats ? '' : 'none';
              if (canViewStats) {
                statsLink.setAttribute('href', '/stats');
                statsLink.setAttribute('data-href', '/stats');
              }
            }
          }

          if (inboxClear && !inboxClear.dataset.bound) {
            inboxClear.dataset.bound = 'true';
            inboxClear.addEventListener('click', async (event) => {
              event.preventDefault();
              event.stopPropagation();
              if (!user || !notifications.length) return;

              try {
                await fetch('/api/notifications/clear', { method: 'POST' });
              } catch (e) {}

              notifications = [];
              unreadCount = 0;
              renderNotifications();
              syncUnreadCount(0);
            });
          }

          if (inboxToggle && !inboxToggle.dataset.bound) {
            inboxToggle.dataset.bound = 'true';
            inboxToggle.addEventListener('click', async (event) => {
              event.preventDefault();
              event.stopPropagation();
              const menu = inboxToggle.closest('.inbox-menu');
              const dropdown = menu && menu.querySelector('[data-inbox-dropdown]');
              const expanded = inboxToggle.getAttribute('aria-expanded') === 'true';
              if (dropdown) dropdown.hidden = expanded;
              inboxToggle.setAttribute('aria-expanded', String(!expanded));
              if (menu) menu.classList.toggle('is-open', !expanded);

              if (!expanded && user && unreadCount > 0) {
                try {
                  await fetch('/api/notifications/read', { method: 'POST' });
                } catch (e) {}
                notifications = notifications.map(notification => notification.readAt ? notification : { ...notification, readAt: new Date().toISOString() });
                renderNotifications();
                syncUnreadCount(0);
              }

              const accountMenuEl = document.querySelector('.account-menu');
              if (accountMenuEl) {
                accountMenuEl.classList.remove('is-open');
                const accountToggleEl = accountMenuEl.querySelector('[data-account-toggle]');
                const accountDropdownEl = accountMenuEl.querySelector('[data-account-dropdown]');
                if (accountToggleEl) accountToggleEl.setAttribute('aria-expanded', 'false');
                if (accountDropdownEl) accountDropdownEl.hidden = true;
              }
            });
          }

          if (accountToggle && !accountToggle.dataset.bound) {
            accountToggle.dataset.bound = 'true';
            accountToggle.addEventListener('click', (event) => {
              event.preventDefault();
              event.stopPropagation();
              const menu = accountToggle.closest('.account-menu');
              const dropdown = menu && menu.querySelector('[data-account-dropdown]');
              const expanded = accountToggle.getAttribute('aria-expanded') === 'true';
              if (dropdown) dropdown.hidden = expanded;
              accountToggle.setAttribute('aria-expanded', String(!expanded));
              if (menu) menu.classList.toggle('is-open', !expanded);

              const inboxMenuEl = document.querySelector('.inbox-menu');
              if (inboxMenuEl) {
                inboxMenuEl.classList.remove('is-open');
                const inboxToggleEl = inboxMenuEl.querySelector('[data-inbox-toggle]');
                const inboxDropdownEl = inboxMenuEl.querySelector('[data-inbox-dropdown]');
                if (inboxToggleEl) inboxToggleEl.setAttribute('aria-expanded', 'false');
                if (inboxDropdownEl) inboxDropdownEl.hidden = true;
              }
            });
          }

          if (!window.__navMenusListenerBound) {
            window.__navMenusListenerBound = true;
            document.addEventListener('click', (event) => {
              ['.inbox-menu', '.account-menu'].forEach(selector => {
                const menu = document.querySelector(selector);
                if (!menu || !menu.classList.contains('is-open')) return;
                if (menu.contains(event.target)) return;
                menu.classList.remove('is-open');
                const toggle = menu.querySelector('button[aria-haspopup="true"]');
                const dropdown = menu.querySelector('[data-inbox-dropdown], [data-account-dropdown]');
                if (toggle) toggle.setAttribute('aria-expanded', 'false');
                if (dropdown) dropdown.hidden = true;
              });
            });
          }

          anchors.forEach(a => {
            // Toggle visibility based on auth status
            const target = a.getAttribute('data-href');
            const navItem = a.closest('li') || a;
            const intent = (() => { try { return sessionStorage.getItem('signup_intent'); } catch (e) { return null; }})();
            if (target === '/login' || target === '/signup') {
              navItem.style.display = user ? 'none' : '';
              if (user) a.setAttribute('href', target);
            } else if (target === '/team-register') {
              navItem.style.display = '';
              if (user) {
                a.setAttribute('href', target);
              } else {
                const label = encodeURIComponent((a.textContent || '').trim());
                a.setAttribute('href', `/auth-gate?next=${encodeURIComponent(target)}${label ? `&label=${label}` : ''}`);
              }
            } else if (target === '/manage-team') {
              navItem.style.display = (user && user.hasTeam) ? '' : 'none';
              if (user) a.setAttribute('href', target);
            } else if (target === '/stats') {
              const canViewStats = Boolean(user && user.canViewStats);
              navItem.style.display = canViewStats ? '' : 'none';
              if (canViewStats) a.setAttribute('href', target);
            } else if (target === '/team-email-directory') {
              navItem.hidden = !canViewTeamEmailDirectory;
              navItem.style.display = canViewTeamEmailDirectory ? '' : 'none';
              if (canViewTeamEmailDirectory) a.setAttribute('href', target);
            } else if (target === '/my-applications' || target === '/join-form') {
              // Show applications/join form only for students.
              // If the user is focused on registering a team, keep the header focused on that path instead.
              navItem.style.display = (user && !user.hasTeam && intent !== 'manager') ? '' : 'none';
              a.setAttribute('href', target);
            } else if (target === '/my-team') {
              navItem.style.display = (user && user.hasTeam) ? '' : 'none';
              if (user) a.setAttribute('href', target);
            }
          });
        }).catch(() => {});

      }).catch(() => {});

    // (removed) prefix calculation — always use absolute paths for partials
}
